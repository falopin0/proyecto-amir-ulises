/**
 * ARCHIVO PRINCIPAL DE LÓGICA JAVASCRIPT: app.js
 * Red Social "CP-ROS" — Sopapa & Viridio
 *
 * Funcionalidades y controladores:
 * 1. Sistema no bloqueante de carteles emergentes y avisos tipo Toast (sin alert nativo).
 * 2. Gestión de perfiles individuales, sesión activa y perfil de invitado.
 * 3. Preservación del fondo personalizado (background) por perfil individual en localStorage.
 * 4. Actualización dinámica y en tiempo real de solicitudes de amistad pendientes y sus contadores.
 * 5. Sistema de mensajería privada con notificaciones emergentes dirigidas únicamente al perfil destinatario.
 * 6. Sistema completo e interactivo de comentarios para las publicaciones del feed.
 * 7. Control de ventanas modales y navegación rápida retro.
 */

// =============================================================================
// 1. SISTEMA DE TOASTS Y CARTELES AVISO (REEMPLAZO DE ALERT NATIVO DEL NAVEGADOR)
// =============================================================================

/**
 * Muestra una notificación emergente estilizada y no bloqueante.
 * @param {string} mensaje - Texto del aviso a mostrar.
 * @param {string} tipo - 'info', 'success', 'error', 'mensaje'.
 * @param {number} duracion - Tiempo en milisegundos antes de desaparecer (default: 3500ms).
 */
function mostrarToast(mensaje, tipo = 'info', duracion = 3500) {
  let toastContainer = document.getElementById('toast-container');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.id = 'toast-container';
    document.body.appendChild(toastContainer);
  }

  const toast = document.createElement('div');
  toast.className = `toast-item toast-${tipo}`;

  let icono = 'ℹ️';
  if (tipo === 'success') icono = '✅';
  if (tipo === 'error') icono = '❌';
  if (tipo === 'mensaje') icono = '📩';

  toast.innerHTML = `
    <div style="display: flex; align-items: center; gap: 8px;">
      <span style="font-size: 16px;">${icono}</span>
      <span>${mensaje}</span>
    </div>
    <button class="toast-close" title="Cerrar aviso" aria-label="Cerrar">✕</button>
  `;

  const btnCerrar = toast.querySelector('.toast-close');
  btnCerrar.addEventListener('click', () => {
    toast.remove();
  });

  toastContainer.appendChild(toast);

  if (duracion > 0) {
    setTimeout(() => {
      if (toast.parentElement) {
        toast.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
      }
    }, duracion);
  }
}

// Reemplazar window.alert por nuestro sistema de avisos integrados para evitar popups nativos del navegador
window.alert = function(msg) {
  mostrarToast(msg, 'info');
};

// =============================================================================
// 2. GESTIÓN DE USUARIO ACTIVO Y SESIÓN (PERFILES INDIVIDUALES & INVITADO)
// =============================================================================

/**
 * Normaliza nombres de usuario para claves únicas en almacenamiento local.
 * @param {string} username
 * @returns {string}
 */
function normalizarUsername(username) {
  if (!username) return 'invitado';
  const u = String(username).toLowerCase().trim();
  if (u.includes('ulises')) return 'ulises';
  if (u.includes('amir')) return 'amir';
  if (u.includes('fede')) return 'fedep';
  if (u.includes('invitado')) return 'invitado';
  return u.replace(/[^a-z0-9_-]/g, '');
}

/**
 * Obtiene los datos del usuario activo desde sessionStorage o contexto de página.
 * @returns {Object}
 */
function obtenerUsuarioActivo() {
  const sesionRaw = sessionStorage.getItem('cpros_usuario');
  if (sesionRaw) {
    try {
      const u = JSON.parse(sesionRaw);
      return u;
    } catch (e) {
      console.warn('Error al parsear cpros_usuario de sessionStorage', e);
    }
  }

  // Si no hay sessionStorage, inferir según la página actual o default
  const path = window.location.pathname.toLowerCase();
  if (path.includes('ulises.html')) {
    return {
      id_usuario: 1,
      usuario_login: 'ulisesl+kpo',
      username: 'ulisesl+kpo',
      nombre_usuario: 'ulisesl+kpo',
      avatar: 'img/hk.jpg',
      es_invitado: false
    };
  } else if (path.includes('amir.html')) {
    return {
      id_usuario: 2,
      usuario_login: 'amir1234',
      username: 'amir1234',
      nombre_usuario: 'amir1234',
      avatar: 'img/mesi.jpg',
      es_invitado: false
    };
  }

  // Por defecto si no inició sesión
  return {
    id_usuario: 0,
    usuario_login: 'Invitado',
    username: 'Invitado',
    nombre_usuario: 'Invitado',
    avatar: 'img/images.jpg',
    es_invitado: true
  };
}

// =============================================================================
// 3. PRESERVACIÓN DE FONDO DE PANTALLA INDIVIDUAL POR PERFIL
// =============================================================================

/**
 * Aplica el fondo personalizado correspondiente al perfil activo.
 */
function cargarFondoPerfil() {
  const usuario = obtenerUsuarioActivo();
  const userKey = normalizarUsername(usuario.usuario_login || usuario.username || usuario.nombre_usuario);
  const fondoGuardado = localStorage.getItem('cpros_bg_' + userKey);

  if (fondoGuardado) {
    document.body.style.backgroundImage = `url('${fondoGuardado}')`;
    document.body.classList.add('custom-bg');
  } else {
    // Si no tiene fondo personalizado guardado para este perfil, remover fondo personalizado
    document.body.classList.remove('custom-bg');
    if (document.body.style.backgroundImage && !document.body.style.backgroundImage.includes('radial-gradient')) {
      document.body.style.backgroundImage = '';
    }
  }
}

/**
 * Guarda el fondo personalizado para el perfil activo.
 * @param {string} dataUrl - Imagen en formato DataURL (Base64).
 */
function guardarFondoPerfil(dataUrl) {
  const usuario = obtenerUsuarioActivo();
  const userKey = normalizarUsername(usuario.usuario_login || usuario.username || usuario.nombre_usuario);
  
  try {
    localStorage.setItem('cpros_bg_' + userKey, dataUrl);
    document.body.style.backgroundImage = `url('${dataUrl}')`;
    document.body.classList.add('custom-bg');
    mostrarToast('🎨 Fondo de pantalla guardado exclusivamente para tu perfil.', 'success');
  } catch (err) {
    console.error('Error al guardar fondo en localStorage:', err);
    mostrarToast('⚠️ La imagen es demasiado pesada para almacenar localmente.', 'error');
  }
}

// =============================================================================
// 4. GESTIÓN DINÁMICA DE SOLICITUDES DE AMISTAD PENDIENTES
// =============================================================================

const SOLICITUDES_INICIALES = [
  {
    id: 1,
    nombre: 'rompeviejas747',
    avatar: 'https://i.pravatar.cc/60?u=3',
    amigosComun: '2 (Batistuta, tukito)',
    fecha: 'Hace 2 horas'
  }
];

function obtenerSolicitudesPendientes() {
  const usuario = obtenerUsuarioActivo();
  const userKey = normalizarUsername(usuario.usuario_login || usuario.username || usuario.nombre_usuario);
  const raw = localStorage.getItem('cpros_solicitudes_' + userKey);

  if (raw !== null) {
    try {
      return JSON.parse(raw);
    } catch (e) {
      return [];
    }
  }
  return [...SOLICITUDES_INICIALES];
}

function guardarSolicitudesPendientes(lista) {
  const usuario = obtenerUsuarioActivo();
  const userKey = normalizarUsername(usuario.usuario_login || usuario.username || usuario.nombre_usuario);
  localStorage.setItem('cpros_solicitudes_' + userKey, JSON.stringify(lista));
  actualizarBadgesSolicitudes(lista.length);
}

function actualizarBadgesSolicitudes(cantidad) {
  const badges = document.querySelectorAll('.btn-solicitudes .badge-count');
  badges.forEach(badge => {
    badge.textContent = cantidad;
    if (cantidad <= 0) {
      badge.style.display = 'none';
    } else {
      badge.style.display = 'inline-block';
    }
  });
}

function aceptarSolicitudAmistad(idSolicitud, nombreSolicitante) {
  let pendientes = obtenerSolicitudesPendientes();
  pendientes = pendientes.filter(s => s.id !== idSolicitud);
  guardarSolicitudesPendientes(pendientes);

  mostrarToast(`¡Has aceptado la solicitud de ${nombreSolicitante}! Ahora son amiguitos.`, 'success');
  renderizarModalSolicitudes();
}

function rechazarSolicitudAmistad(idSolicitud, nombreSolicitante) {
  let pendientes = obtenerSolicitudesPendientes();
  pendientes = pendientes.filter(s => s.id !== idSolicitud);
  guardarSolicitudesPendientes(pendientes);

  mostrarToast(`Solicitud de ${nombreSolicitante} rechazada.`, 'info');
  renderizarModalSolicitudes();
}

// =============================================================================
// 5. SISTEMA DE MENSAJES PRIVADOS Y NOTIFICACIONES AL DESTINATARIO
// =============================================================================

/**
 * Envía un mensaje privado y lo almacena para el perfil destinatario.
 * @param {string} destinatario
 * @param {string} contenido
 */
function enviarMensajePrivado(destinatario, contenido) {
  const remitente = obtenerUsuarioActivo();
  const nombreRemitente = remitente.usuario_login || remitente.username || remitente.nombre_usuario || 'Usuario';
  const targetKey = normalizarUsername(destinatario);

  const nuevoMensaje = {
    id: Date.now(),
    remitente: nombreRemitente,
    destinatario: destinatario.trim(),
    contenido: contenido.trim(),
    fecha: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' ' + new Date().toLocaleDateString(),
    leido: false
  };

  const claveInbox = 'cpros_mensajes_' + targetKey;
  let inbox = [];
  try {
    const raw = localStorage.getItem(claveInbox);
    if (raw) inbox = JSON.parse(raw);
  } catch (e) {}

  inbox.unshift(nuevoMensaje);
  localStorage.setItem(claveInbox, JSON.stringify(inbox));

  // Notificar al emisor
  mostrarToast(`✉️ Mensaje privado enviado exitosamente a ${destinatario}.`, 'success');

  // Cerrar modal
  const modalContainer = document.getElementById('modal-container');
  if (modalContainer) modalContainer.classList.add('hidden');
}

/**
 * Revisa si el perfil activo tiene nuevos mensajes privados y muestra el cartel emergente correspondiente.
 */
function verificarMensajesEntrantesPerfil() {
  const usuario = obtenerUsuarioActivo();
  if (usuario.es_invitado) return; // Los invitados no tienen bandeja personal de mensajes

  const userKey = normalizarUsername(usuario.usuario_login || usuario.username || usuario.nombre_usuario);
  const claveInbox = 'cpros_mensajes_' + userKey;
  
  let inbox = [];
  try {
    const raw = localStorage.getItem(claveInbox);
    if (raw) inbox = JSON.parse(raw);
  } catch (e) {}

  const noLeidos = inbox.filter(m => !m.leido);

  if (noLeidos.length > 0) {
    // Mostrar cartel emergente no invasivo para el destinatario
    noLeidos.forEach(msg => {
      mostrarToast(`📩 Mensaje nuevo de @${msg.remitente}: "${msg.contenido}"`, 'mensaje', 6000);
      msg.leido = true;
    });

    localStorage.setItem(claveInbox, JSON.stringify(inbox));
    actualizarBadgesNotificaciones(inbox.length);
  }
}

function actualizarBadgesNotificaciones(cantidad) {
  const badges = document.querySelectorAll('.btn-notificaciones .badge-count');
  badges.forEach(badge => {
    badge.textContent = Math.max(3, cantidad);
  });
}

// =============================================================================
// 6. SISTEMA DINÁMICO DE COMENTARIOS EN PUBLICACIONES
// =============================================================================

/**
 * Publica un comentario en la publicación indicada.
 * @param {Event} e
 * @param {number} idPublicacion
 */
async function publicarComentario(e, idPublicacion) {
  if (e && e.preventDefault) e.preventDefault();

  const input = document.getElementById(`input-comentario-${idPublicacion}`);
  if (!input) return;

  const contenido = input.value.trim();
  if (!contenido) return;

  const usuario = obtenerUsuarioActivo();
  const nombreAutor = usuario.usuario_login || usuario.username || usuario.nombre_usuario || 'Invitado';
  const avatarAutor = usuario.avatar || 'img/images.jpg';
  const idUsuario = usuario.id_usuario || null;

  // Intentar enviar al backend PHP si está disponible
  try {
    const resp = await fetch('php/api/comentarios.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id_publicacion: idPublicacion,
        id_usuario: idUsuario,
        nombre_autor: nombreAutor,
        avatar_autor: avatarAutor,
        contenido: contenido
      })
    });

    if (resp.ok) {
      const data = await resp.json();
      if (data.exito && data.comentario) {
        insertarComentarioEnDOM(idPublicacion, data.comentario);
        input.value = '';
        mostrarToast('💬 Comentario publicado correctamente.', 'success');
        return;
      }
    }
  } catch (err) {
    console.warn('Backend PHP no disponible para comentarios, usando renderizado dinámico local:', err);
  }

  // Fallback local instantáneo
  const nuevoComentario = {
    id_comentario: Date.now(),
    id_publicacion: idPublicacion,
    nombre_autor: nombreAutor,
    avatar_autor: avatarAutor,
    contenido: contenido,
    fecha_formateada: 'Recién publicado'
  };

  insertarComentarioEnDOM(idPublicacion, nuevoComentario);
  input.value = '';
  mostrarToast('💬 Comentario publicado correctamente.', 'success');
}

/**
 * Inserta visualmente un nuevo comentario en la lista del DOM y actualiza el contador.
 */
function insertarComentarioEnDOM(idPublicacion, comentario) {
  const lista = document.getElementById(`lista-comentarios-${idPublicacion}`);
  if (lista) {
    const li = document.createElement('li');
    li.className = 'comentario-item';
    li.innerHTML = `
      <img src="${comentario.avatar_autor || 'img/images.jpg'}" alt="Avatar" class="comentario-avatar">
      <div class="comentario-contenido">
        <span class="comentario-autor">${escaparHTML(comentario.nombre_autor)}</span>
        <span class="comentario-fecha">${escaparHTML(comentario.fecha_formateada || 'Ahora')}</span>
        <div class="comentario-texto">${escaparHTML(comentario.contenido)}</div>
      </div>
    `;
    lista.appendChild(li);
  }

  // Actualizar contador
  const contador = document.getElementById(`cant-comentarios-${idPublicacion}`);
  if (contador) {
    const total = parseInt(contador.textContent || '0', 10) + 1;
    contador.textContent = total;
  }
}

function enfocarComentario(idPublicacion) {
  const input = document.getElementById(`input-comentario-${idPublicacion}`);
  if (input) {
    input.focus();
    input.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

function darLike(idPublicacion) {
  const span = document.getElementById(`likes-count-${idPublicacion}`);
  if (span) {
    const actual = parseInt(span.textContent || '0', 10);
    span.textContent = actual + 1;
    mostrarToast('👍 ¡Te gusta esta publicación!', 'success');
  }
}

function compartirPublicacion(idPublicacion) {
  mostrarToast('🔗 Enlace de la publicación copiado al portapapeles.', 'info');
}

function escaparHTML(texto) {
  if (!texto) return '';
  const div = document.createElement('div');
  div.textContent = texto;
  return div.innerHTML;
}

// =============================================================================
// 7. RENDERIZADO Y CONTROL DE VENTANAS MODALES
// =============================================================================

function abrirModal(title, contentHTML) {
  const modalContainer = document.getElementById('modal-container');
  const modalTitle = document.getElementById('modal-title');
  const modalBody = document.getElementById('modal-body');

  if (modalTitle && modalBody && modalContainer) {
    modalTitle.textContent = title;
    modalBody.innerHTML = contentHTML;
    modalContainer.classList.remove('hidden');
  }
}

function cerrarModal() {
  const modalContainer = document.getElementById('modal-container');
  if (modalContainer) {
    modalContainer.classList.add('hidden');
  }
}

function renderizarModalSolicitudes() {
  const pendientes = obtenerSolicitudesPendientes();
  
  if (pendientes.length === 0) {
    abrirModal('👥 Solicitudes de Amistad Pendientes', `
      <p style="font-size: 13px; color: #555; margin-bottom: 10px;">
        <i>Gestiona quién puede agregarte a su lista de amiguitos y contactarte.</i>
      </p>
      <hr>
      <div style="text-align: center; padding: 25px 10px; color: #666; font-size: 14px;">
        ✨ <strong>No tienes solicitudes de amistad pendientes.</strong>
        <p style="font-size: 12px; color: #888; margin-top: 6px;">Todas las solicitudes entrantes han sido procesadas.</p>
      </div>
      <div style="text-align: right; margin-top: 15px;">
        <button onclick="document.getElementById('modal-container').classList.add('hidden');" style="padding: 6px 14px; background: #3b5998; color: white; border: none; border-radius: 4px; cursor: pointer;">Cerrar</button>
      </div>
    `);
    return;
  }

  let htmlItems = '';
  pendientes.forEach(s => {
    htmlItems += `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; background: #f8f9fa; padding: 10px; border-radius: 6px; border: 1px solid #e9ecef;">
        <div>
          <strong>👤 ${escaparHTML(s.nombre)}</strong><br>
          <span style="font-size: 11px; color: #666;">Amigos en común: ${escaparHTML(s.amigosComun)}</span>
        </div>
        <div style="display: flex; gap: 6px;">
          <button onclick="aceptarSolicitudAmistad(${s.id}, '${escaparHTML(s.nombre)}')" style="background: #2b8a3e; color: white; border: none; padding: 5px 12px; font-size: 12px; border-radius: 4px; cursor: pointer; font-weight: bold;">Aceptar</button>
          <button onclick="rechazarSolicitudAmistad(${s.id}, '${escaparHTML(s.nombre)}')" style="background: #e74c3c; color: white; border: none; padding: 5px 12px; font-size: 12px; border-radius: 4px; cursor: pointer; font-weight: bold;">Rechazar</button>
        </div>
      </div>
    `;
  });

  abrirModal('👥 Solicitudes de Amistad Pendientes', `
    <p style="font-size: 13px; color: #555; margin-bottom: 10px;">
      <i>Gestiona quién puede agregarte a su lista de amiguitos y contactarte.</i>
    </p>
    <hr>
    ${htmlItems}
  `);
}

function renderizarModalNotificaciones() {
  const usuario = obtenerUsuarioActivo();
  const userKey = normalizarUsername(usuario.usuario_login || usuario.username || usuario.nombre_usuario);
  const claveInbox = 'cpros_mensajes_' + userKey;
  
  let mensajes = [];
  try {
    const raw = localStorage.getItem(claveInbox);
    if (raw) mensajes = JSON.parse(raw);
  } catch (e) {}

  let itemsMensajes = '';
  if (mensajes.length > 0) {
    itemsMensajes = '<div style="margin-bottom: 10px; font-weight: bold; font-size: 12px; color: #3b5998;">📩 Mensajes Privados Recibidos:</div>';
    mensajes.slice(0, 5).forEach(m => {
      itemsMensajes += `
        <li style="margin-bottom: 8px; background: #eef4fb; padding: 8px; border-radius: 4px; border-left: 3px solid #3b5998;">
          <strong>De @${escaparHTML(m.remitente)}:</strong> "${escaparHTML(m.contenido)}"
          <div style="font-size: 10px; color: #777; margin-top: 2px;">🕒 ${escaparHTML(m.fecha)}</div>
        </li>
      `;
    });
  }

  abrirModal('🔔 Bandeja de Notificaciones', `
    <p style="font-size: 13px; color: #555; margin-bottom: 10px;">
      <i>Aquí ves las actividades recientes de tus amigos y los mensajes recibidos.</i>
    </p>
    <hr>
    <ul style="list-style: none; padding-left: 0; line-height: 1.6; font-size: 13px;">
      ${itemsMensajes}
      <li style="margin-bottom: 6px;">👥 <b>rompeviejas747</b> te envió una solicitud de amistad.</li>
      <li style="margin-bottom: 6px;">🎮 El juego <b>Minecraft 3</b> se actualizó al parche v1.4.</li>
      <li style="margin-bottom: 6px;">🏆 <b>Shadow</b> batió tu récord en Minecraft 3.</li>
    </ul>
    <div style="text-align: right; margin-top: 15px;">
      <button onclick="document.getElementById('modal-container').classList.add('hidden');" style="padding: 6px 14px; background: #3b5998; color: white; border: none; border-radius: 4px; cursor: pointer;">Entendido</button>
    </div>
  `);
}

// =============================================================================
// 8. INICIALIZACIÓN GLOBAL AL CARGAR EL DOM
// =============================================================================

document.addEventListener('DOMContentLoaded', () => {

  // Crear contenedor modal si no existe
  let modalContainer = document.getElementById('modal-container');
  let closeModalBtn = document.querySelector('.close-modal');

  if (!modalContainer) {
    const modalHTML = `
      <div id="modal-container" class="modal-overlay hidden" role="dialog" aria-modal="true">
        <div class="modal-content">
          <div class="caja-header">
            <span id="modal-title">Título</span>
            <button class="close-modal" aria-label="Cerrar ventana" style="float: right;">✕</button>
          </div>
          <div class="caja-body" id="modal-body">
            <!-- Contenido dinámico -->
          </div>
        </div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    modalContainer = document.getElementById('modal-container');
    closeModalBtn = document.querySelector('.close-modal');
  }

  // Eventos de cierre de modal
  if (closeModalBtn) {
    closeModalBtn.addEventListener('click', cerrarModal);
  }

  if (modalContainer) {
    modalContainer.addEventListener('click', (e) => {
      if (e.target === modalContainer) {
        cerrarModal();
      }
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalContainer && !modalContainer.classList.contains('hidden')) {
      cerrarModal();
    }
  });

  // A) Cargar fondo individual del usuario activo
  cargarFondoPerfil();

  // B) Sincronizar indicador de usuario en la barra superior
  const usuarioActivo = obtenerUsuarioActivo();
  const spanUser = document.querySelector('.top-bar-user');
  if (spanUser) {
    const username = usuarioActivo.usuario_login || usuarioActivo.username || usuarioActivo.nombre_usuario || 'Invitado';
    spanUser.textContent = `👤 ${username}`;
  }

  // C) Inicializar contador de solicitudes
  const solicitudesPendientes = obtenerSolicitudesPendientes();
  actualizarBadgesSolicitudes(solicitudesPendientes.length);

  // D) Verificar mensajes privados entrantes para el usuario activo
  verificarMensajesEntrantesPerfil();

  // E) Asignar botón de Notificaciones
  const btnsNotificaciones = document.querySelectorAll('.btn-notificaciones');
  btnsNotificaciones.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      renderizarModalNotificaciones();
    });
  });

  // F) Asignar botón de Solicitudes
  const btnsSolicitudes = document.querySelectorAll('.btn-solicitudes');
  btnsSolicitudes.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      renderizarModalSolicitudes();
    });
  });

  // G) Asignar botón de Amiguitos
  const btnsAmiguitos = document.querySelectorAll('.btn-amiguitos');
  btnsAmiguitos.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      abrirModal('🫂 Lista Completa de Amiguitos', `
        <p style="font-size: 13px; color: #555; margin-bottom: 10px;">
          <i>Tu círculo de amigos para chatear y competir en juegos.</i>
        </p>
        <hr>
        <div class="grid-amigos" style="margin-top: 10px;">
          <div class="amigo-item">
            <div class="amigo-pic" style="background-image: url('img/fede-p.jpeg')"></div>
            <div class="amigo-nombre">fede p</div>
            <span class="status-online" style="font-size: 10px;">Online</span>
          </div>
          <div class="amigo-item">
            <div class="amigo-pic" style="background-image: url('https://i.pravatar.cc/60?u=2')"></div>
            <div class="amigo-nombre">el niño torres</div>
            <span class="status-online" style="font-size: 10px;">Online</span>
          </div>
          <div class="amigo-item">
            <div class="amigo-pic" style="background-image: url('https://i.pravatar.cc/60?u=3')"></div>
            <div class="amigo-nombre">rompeviejas747</div>
            <span class="status-offline" style="font-size: 10px;">Offline</span>
          </div>
          <div class="amigo-item">
            <div class="amigo-pic" style="background-image: url('https://i.pravatar.cc/60?u=4')"></div>
            <div class="amigo-nombre">tukito</div>
            <span class="status-online" style="font-size: 10px;">Online</span>
          </div>
          <div class="amigo-item">
            <div class="amigo-pic" style="background-image: url('https://i.pravatar.cc/60?u=5')"></div>
            <div class="amigo-nombre">Batistuta</div>
            <span class="status-offline" style="font-size: 10px;">Offline</span>
          </div>
          <div class="amigo-item">
            <div class="amigo-pic" style="background-image: url('https://i.pravatar.cc/60?u=6')"></div>
            <div class="amigo-nombre">Serafio</div>
            <span class="status-offline" style="font-size: 10px;">Offline</span>
          </div>
        </div>
      `);
    });
  });

  // H) Asignar botón de Mensajes Privados
  const btnsMensajes = document.querySelectorAll('.btn-mensajes');
  btnsMensajes.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const usuario = obtenerUsuarioActivo();
      const currentName = usuario.usuario_login || usuario.username || '';
      const defaultDestino = currentName.includes('ulises') ? 'amir1234' : 'ulisesl+kpo';

      abrirModal('✉️ Redactar Mensaje Privado', `
        <p style="font-size: 13px; color: #555; margin-bottom: 10px;">
          <i>Envía un mensaje privado instantáneo a otro usuario de la red.</i>
        </p>
        <hr>
        <form id="form-modal-mensaje" onsubmit="event.preventDefault(); const d = document.getElementById('msg-destinatario').value; const m = document.getElementById('msg-contenido').value; enviarMensajePrivado(d, m);">
          <label style="font-size: 12px; font-weight: bold; display: block; margin-bottom: 4px;">Destinatario (Username):</label>
          <input type="text" id="msg-destinatario" placeholder="Nombre de usuario..." value="${defaultDestino}" required style="width: 100%; padding: 8px; margin-bottom: 10px; box-sizing: border-box; border: 1px solid #bdc3c7; border-radius: 4px;">

          <label style="font-size: 12px; font-weight: bold; display: block; margin-bottom: 4px;">Mensaje:</label>
          <textarea id="msg-contenido" placeholder="Escribe tu mensaje privado aquí..." required style="width: 100%; height: 90px; padding: 8px; margin-bottom: 12px; box-sizing: border-box; border: 1px solid #bdc3c7; border-radius: 4px;"></textarea>

          <div style="text-align: right;">
            <button type="submit" style="background: #4267b2; color: white; border: none; padding: 8px 16px; border-radius: 4px; font-weight: bold; cursor: pointer;">Enviar Mensaje 🚀</button>
          </div>
        </form>
      `);
    });
  });

  // I) Personalización del Fondo de Pantalla (FileReader y guardado por perfil)
  const btnPersonalizar = document.getElementById('btn-personalizar');
  const bgUpload = document.getElementById('bg-upload');

  if (btnPersonalizar && bgUpload) {
    btnPersonalizar.addEventListener('click', () => {
      bgUpload.click();
    });

    bgUpload.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          guardarFondoPerfil(event.target.result);
        };
        reader.readAsDataURL(file);
      }
    });
  }

});
