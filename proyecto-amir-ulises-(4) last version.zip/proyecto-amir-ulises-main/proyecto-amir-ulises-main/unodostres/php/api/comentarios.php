<?php
/**
 * ENDPOINT API: Comentarios de Publicaciones
 * Ruta: php/api/comentarios.php
 * Métodos: GET, POST
 *
 * Permite listar y publicar comentarios en las publicaciones del feed.
 */

session_start();

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../modelos/Comentario.php';
require_once __DIR__ . '/../modelos/Usuario.php';

$metodo = $_SERVER['REQUEST_METHOD'];

// ============================================================================
// GET: Obtener comentarios de una publicación o todos agrupados
// ============================================================================
if ($metodo === 'GET') {
    $idPublicacion = isset($_GET['id_publicacion']) ? intval($_GET['id_publicacion']) : null;

    if ($idPublicacion) {
        $comentarios = Comentario::obtenerPorPublicacion($idPublicacion);
    } else {
        $comentarios = Comentario::obtenerTodosAgrupados();
    }

    http_response_code(200);
    echo json_encode([
        'exito'       => true,
        'comentarios' => $comentarios,
        'datos'       => $comentarios
    ]);
    exit;
}

// ============================================================================
// POST: Crear un nuevo comentario
// ============================================================================
if ($metodo === 'POST') {
    $datos = json_decode(file_get_contents('php://input'), true);
    if (!$datos || !is_array($datos)) {
        $datos = $_POST;
    }

    $idPublicacion = isset($datos['id_publicacion']) ? intval($datos['id_publicacion']) : 0;
    $contenido     = isset($datos['contenido'])      ? trim($datos['contenido'])           : '';
    $idUsuario     = isset($datos['id_usuario'])      ? intval($datos['id_usuario'])       : (isset($_SESSION['id_usuario']) ? intval($_SESSION['id_usuario']) : null);
    
    // Obtener nombre y avatar del usuario o sesión o datos provistos
    $nombreAutor = '';
    $avatarAutor = 'img/images.jpg';

    if ($idUsuario) {
        $usuario = Usuario::obtenerPorId($idUsuario);
        if ($usuario) {
            $nombreAutor = $usuario['nombre_usuario'];
            $avatarAutor = $usuario['avatar'] ?: 'img/images.jpg';
        }
    }

    if (empty($nombreAutor)) {
        if (!empty($datos['nombre_autor'])) {
            $nombreAutor = trim($datos['nombre_autor']);
        } elseif (isset($_SESSION['usuario_login'])) {
            $nombreAutor = $_SESSION['usuario_login'];
        } elseif (isset($_SESSION['nombre_usuario'])) {
            $nombreAutor = $_SESSION['nombre_usuario'];
        } else {
            $nombreAutor = 'Invitado';
        }
    }

    if (!empty($datos['avatar_autor'])) {
        $avatarAutor = $datos['avatar_autor'];
    } elseif (isset($_SESSION['avatar'])) {
        $avatarAutor = $_SESSION['avatar'];
    }

    if (!$idPublicacion || empty($contenido)) {
        http_response_code(400);
        echo json_encode([
            'exito'   => false,
            'mensaje' => 'Se requiere el ID de publicación y el texto del comentario.'
        ]);
        exit;
    }

    $idComentario = Comentario::crear($idPublicacion, $idUsuario, $nombreAutor, $contenido, $avatarAutor);

    if ($idComentario) {
        http_response_code(201);
        echo json_encode([
            'exito'      => true,
            'mensaje'    => 'Comentario publicado con éxito.',
            'comentario' => [
                'id_comentario'    => $idComentario,
                'id_publicacion'   => $idPublicacion,
                'id_usuario'       => $idUsuario,
                'nombre_autor'     => htmlspecialchars($nombreAutor, ENT_QUOTES, 'UTF-8'),
                'avatar_autor'     => htmlspecialchars($avatarAutor, ENT_QUOTES, 'UTF-8'),
                'contenido'        => htmlspecialchars($contenido, ENT_QUOTES, 'UTF-8'),
                'fecha_formateada' => date('d/m/Y H:i'),
                'fecha_comentario' => date('Y-m-d H:i:s')
            ]
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            'exito'   => false,
            'mensaje' => 'No se pudo guardar el comentario en la base de datos.'
        ]);
    }
    exit;
}

http_response_code(405);
echo json_encode(['exito' => false, 'mensaje' => 'Método no permitido.']);
