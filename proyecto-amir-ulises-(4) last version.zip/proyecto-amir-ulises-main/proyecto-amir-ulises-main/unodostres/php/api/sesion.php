<?php
/**
 * ENDPOINT API: Verificar Sesión Activa
 * Ruta: php/api/sesion.php
 * Método: GET
 */

session_start();

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

if (isset($_SESSION['es_invitado']) && $_SESSION['es_invitado'] === true) {
    $datosUsuario = [
        'id_usuario'      => 0,
        'usuario_login'   => 'Invitado',
        'username'        => 'Invitado',
        'nombre_usuario'  => 'Invitado',
        'nombre_completo' => 'Invitado',
        'avatar'          => 'img/images.jpg',
        'fondo'           => '',
        'estado'          => 'online',
        'edad_texto'      => 'Explorador',
        'ubicacion'       => 'Comunidad CP-ROS',
        'ultimo_login'    => date('d/m/Y H:i'),
        'es_invitado'     => true
    ];

    http_response_code(200);
    echo json_encode([
        'exito'     => true,
        'logueado'  => true,
        'usuario'   => $datosUsuario,
        'datos'     => $datosUsuario
    ]);
    exit;
}

if (isset($_SESSION['logueado']) && $_SESSION['logueado'] === true && isset($_SESSION['id_usuario'])) {

    require_once __DIR__ . '/../conexion.php';
    require_once __DIR__ . '/../modelos/Usuario.php';
    require_once __DIR__ . '/../modelos/ActividadUsuario.php';

    $idUsuario = (int)$_SESSION['id_usuario'];
    $usuario   = Usuario::obtenerPorId($idUsuario);
    $actividad = ActividadUsuario::obtenerPorIdUsuario($idUsuario);

    $username = isset($_SESSION['usuario_login']) ? $_SESSION['usuario_login'] : (isset($_SESSION['usuario']) ? $_SESSION['usuario'] : ($usuario ? $usuario['nombre_usuario'] : ''));

    $datosUsuario = [
        'id_usuario'      => $idUsuario,
        'usuario_login'   => $username,
        'username'        => $username,
        'nombre_usuario'  => $username,
        'nombre_completo' => $usuario ? $usuario['nombre_usuario'] : $username,
        'avatar'          => $usuario ? $usuario['avatar'] : 'img/images.jpg',
        'fondo'           => $usuario ? $usuario['fondo']  : '',
        'estado'          => $actividad ? $actividad['estado']      : 'online',
        'edad_texto'      => $actividad ? $actividad['edad_texto']  : 'Sin especificar',
        'ubicacion'       => $actividad ? $actividad['ubicacion']   : 'Sin especificar',
        'ultimo_login'    => $actividad ? $actividad['ultimo_login']: date('d/m/Y H:i'),
        'es_invitado'     => false
    ];

    http_response_code(200);
    echo json_encode([
        'exito'     => true,
        'logueado'  => true,
        'usuario'   => $datosUsuario,
        'datos'     => $datosUsuario
    ]);
} else {
    http_response_code(200);
    echo json_encode([
        'exito'    => true,
        'logueado' => false,
        'mensaje'  => 'No hay sesión activa. El usuario debe iniciar sesión.',
        'usuario'  => null,
        'datos'    => null
    ]);
}
