<?php
/**
 * MODELO: Comentario
 * Tabla: comentarios (Base de datos: u283509122_cyp)
 * Campos: id_comentario, id_publicacion, id_usuario, nombre_autor, avatar_autor, contenido, fecha_comentario
 *
 * Gestiona los comentarios de las publicaciones del feed en CP-ROS.
 */

require_once __DIR__ . '/../conexion.php';

class Comentario {

    /**
     * Obtener todos los comentarios de una publicación específica.
     * @param int $idPublicacion
     * @return array
     */
    public static function obtenerPorPublicacion($idPublicacion) {
        $db = obtenerConexion();
        if (!$db) return [];

        try {
            $stmt = $db->prepare(
                "SELECT c.id_comentario, c.id_publicacion, c.id_usuario, c.nombre_autor,
                        c.avatar_autor, c.contenido, c.fecha_comentario,
                        COALESCE(DATE_FORMAT(c.fecha_comentario, '%d/%m/%Y %H:%i'), c.fecha_comentario) AS fecha_formateada,
                        u.nombre_usuario AS usuario_db_nombre, u.avatar AS usuario_db_avatar
                 FROM comentarios c
                 LEFT JOIN usuario u ON c.id_usuario = u.id_usuario
                 WHERE c.id_publicacion = :id_publicacion
                 ORDER BY c.fecha_comentario ASC, c.id_comentario ASC"
            );
            $stmt->execute([':id_publicacion' => (int)$idPublicacion]);
            $comentarios = $stmt->fetchAll() ?: [];

            // Asegurar nombre y avatar correctos
            foreach ($comentarios as &$com) {
                if (!empty($com['usuario_db_nombre'])) {
                    $com['nombre_autor'] = $com['usuario_db_nombre'];
                }
                if (!empty($com['usuario_db_avatar'])) {
                    $com['avatar_autor'] = $com['usuario_db_avatar'];
                }
            }

            return $comentarios;
        } catch (PDOException $e) {
            error_log("Error al obtener comentarios de publicación: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Obtener todos los comentarios agrupados por id_publicacion.
     * @return array [id_publicacion => [comentario, ...]]
     */
    public static function obtenerTodosAgrupados() {
        $db = obtenerConexion();
        if (!$db) return [];

        try {
            $stmt = $db->prepare(
                "SELECT c.id_comentario, c.id_publicacion, c.id_usuario, c.nombre_autor,
                        c.avatar_autor, c.contenido, c.fecha_comentario,
                        COALESCE(DATE_FORMAT(c.fecha_comentario, '%d/%m/%Y %H:%i'), c.fecha_comentario) AS fecha_formateada,
                        u.nombre_usuario AS usuario_db_nombre, u.avatar AS usuario_db_avatar
                 FROM comentarios c
                 LEFT JOIN usuario u ON c.id_usuario = u.id_usuario
                 ORDER BY c.fecha_comentario ASC, c.id_comentario ASC"
            );
            $stmt->execute();
            $lista = $stmt->fetchAll() ?: [];

            $agrupados = [];
            foreach ($lista as $c) {
                if (!empty($c['usuario_db_nombre'])) {
                    $c['nombre_autor'] = $c['usuario_db_nombre'];
                }
                if (!empty($c['usuario_db_avatar'])) {
                    $c['avatar_autor'] = $c['usuario_db_avatar'];
                }
                $pubId = (int)$c['id_publicacion'];
                if (!isset($agrupados[$pubId])) {
                    $agrupados[$pubId] = [];
                }
                $agrupados[$pubId][] = $c;
            }

            return $agrupados;
        } catch (PDOException $e) {
            error_log("Error al listar comentarios agrupados: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Crear un nuevo comentario en una publicación.
     * @param int $idPublicacion
     * @param int|null $idUsuario
     * @param string $nombreAutor
     * @param string $contenido
     * @param string $avatarAutor
     * @return int|false ID del comentario insertado o false
     */
    public static function crear($idPublicacion, $idUsuario, $nombreAutor, $contenido, $avatarAutor = 'img/images.jpg') {
        $db = obtenerConexion();
        if (!$db) return false;

        try {
            $stmt = $db->prepare(
                "INSERT INTO comentarios (id_publicacion, id_usuario, nombre_autor, avatar_autor, contenido, fecha_comentario)
                 VALUES (:id_publicacion, :id_usuario, :nombre_autor, :avatar_autor, :contenido, NOW())"
            );
            $exito = $stmt->execute([
                ':id_publicacion' => (int)$idPublicacion,
                ':id_usuario'     => $idUsuario ? (int)$idUsuario : null,
                ':nombre_autor'   => trim($nombreAutor),
                ':avatar_autor'   => $avatarAutor ?: 'img/images.jpg',
                ':contenido'      => trim($contenido)
            ]);

            return $exito ? (int)$db->lastInsertId() : false;
        } catch (PDOException $e) {
            error_log("Error al crear comentario: " . $e->getMessage());
            return false;
        }
    }
}
