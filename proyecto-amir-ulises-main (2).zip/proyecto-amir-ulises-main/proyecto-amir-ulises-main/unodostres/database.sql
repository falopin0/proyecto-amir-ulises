-- ============================================================================
-- SCRIPT DE BASE DE DATOS: u283509122_cyp
-- Red Social "CP-ROS" — Sopapa & Viridio
-- Compatible con MySQL 5.7+, MySQL 8.0+, MariaDB y HeidiSQL / phpMyAdmin
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `u283509122_cyp` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `u283509122_cyp`;

-- Desactivar temporalmente claves foráneas para recreación segura
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- 1. TABLA: usuario (Perfiles principales de la red social)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `usuario` (
  `id_usuario` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre_usuario` VARCHAR(100) NOT NULL UNIQUE,
  `avatar` VARCHAR(255) NOT NULL DEFAULT 'img/images.jpg',
  `fondo` VARCHAR(255) NOT NULL DEFAULT '',
  `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 2. TABLA: inicio_sesion (Credenciales de acceso con contraseñas hasheadas)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `inicio_sesion` (
  `id_inicio_sesion` INT AUTO_INCREMENT PRIMARY KEY,
  `id_usuario` INT NOT NULL,
  `usuario_login` VARCHAR(100) NOT NULL UNIQUE,
  `contrasena_hash` VARCHAR(255) NOT NULL,
  `contrasena_hex` VARCHAR(255) DEFAULT NULL,
  `fecha_registro` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_iniciosesion_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3. TABLA: actividad_usuario (Información biográfica, estado y último acceso)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `actividad_usuario` (
  `id_actividad` INT AUTO_INCREMENT PRIMARY KEY,
  `id_usuario` INT NOT NULL,
  `estado` VARCHAR(255) NOT NULL DEFAULT '¡Hola! Estoy usando CP-ROS.',
  `edad_texto` VARCHAR(50) NOT NULL DEFAULT '20 años',
  `ubicacion` VARCHAR(100) NOT NULL DEFAULT 'Buenos Aires, Argentina',
  `ultimo_login` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_actividad_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 4. TABLA: amiguitos (Lista de amigos y perfiles vinculados)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `amiguitos` (
  `id_amiguito` INT AUTO_INCREMENT PRIMARY KEY,
  `id_usuario` INT NOT NULL,
  `id_amigo` INT NOT NULL,
  `nombre_amigo` VARCHAR(100) NOT NULL,
  `avatar_amigo` VARCHAR(255) NOT NULL DEFAULT 'img/images.jpg',
  `enlace_perfil` VARCHAR(255) NOT NULL DEFAULT 'amir.html',
  `fecha_amistad` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_amiguitos_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 5. TABLA: publicaciones (Publicaciones dinámicas en el feed de la comunidad)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `publicaciones` (
  `id_publicacion` INT AUTO_INCREMENT PRIMARY KEY,
  `id_usuario` INT NOT NULL,
  `autor_nombre` VARCHAR(100) NOT NULL,
  `avatar` VARCHAR(255) NOT NULL DEFAULT 'img/images.jpg',
  `contenido` TEXT NOT NULL,
  `fecha_publicacion` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `me_gusta` INT DEFAULT 0,
  CONSTRAINT `fk_publicaciones_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 6. TABLA: registro (Historial de altas y correos electrónicos)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `registro` (
  `id_registro` INT AUTO_INCREMENT PRIMARY KEY,
  `id_usuario` INT NOT NULL,
  `correo` VARCHAR(150) NOT NULL,
  `fecha_alta` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_registro_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================================
-- DATOS INICIALES POR DEFECTO (SEED)
-- Contraseña para los usuarios iniciales ("ulises" y "amir"): 123456
-- Hash Bcrypt generado con password_hash('123456', PASSWORD_DEFAULT)
-- ============================================================================

-- Insertar usuarios iniciales
INSERT INTO `usuario` (`id_usuario`, `nombre_usuario`, `avatar`, `fondo`) VALUES
(1, 'ulises', 'img/txi.jpg', 'img/gun2.0.png'),
(2, 'amir', 'img/mesi.jpg', 'img/fede-p.jpeg')
ON DUPLICATE KEY UPDATE `nombre_usuario` = VALUES(`nombre_usuario`);

-- Insertar credenciales de acceso iniciales (contraseña: 123456)
-- Hash: $2y$10$y58o64fC7e5m7gWzCvhLq.m2pvyfEomQ1y3m8gE4vL.N/z2vJqZ4a (ejemplo Bcrypt)
INSERT INTO `inicio_sesion` (`id_usuario`, `usuario_login`, `contrasena_hash`, `contrasena_hex`) VALUES
(1, 'ulises', '$2y$10$Q7w/O7GZcQ.8K1lE9uNnveWwTqN0l7rP5pC5H0uVv9A7L9hP9g5jK', '313233343536'),
(2, 'amir', '$2y$10$Q7w/O7GZcQ.8K1lE9uNnveWwTqN0l7rP5pC5H0uVv9A7L9hP9g5jK', '313233343536')
ON DUPLICATE KEY UPDATE `usuario_login` = VALUES(`usuario_login`);

-- Insertar actividad de perfil
INSERT INTO `actividad_usuario` (`id_usuario`, `estado`, `edad_texto`, `ubicacion`) VALUES
(1, 'Subiendo de rango en Minecraft y armando partidas retro 🎮', '20 años', 'Argentina'),
(2, 'Clavando un switch half-cab heelflip en Lyon 25 🛹', '21 años', 'Argentina')
ON DUPLICATE KEY UPDATE `estado` = VALUES(`estado`);

-- Insertar vínculos de amiguitos
INSERT INTO `amiguitos` (`id_usuario`, `id_amigo`, `nombre_amigo`, `avatar_amigo`, `enlace_perfil`) VALUES
(1, 2, 'Amir', 'img/mesi.jpg', 'amir.html'),
(2, 1, 'Ulises', 'img/txi.jpg', 'ulises.html')
ON DUPLICATE KEY UPDATE `nombre_amigo` = VALUES(`nombre_amigo`);

-- Insertar publicaciones iniciales de la comunidad
INSERT INTO `publicaciones` (`id_usuario`, `autor_nombre`, `avatar`, `contenido`, `fecha_publicacion`, `me_gusta`) VALUES
(1, 'Ulises', 'img/txi.jpg', '¡Bienvenidos a todos a CP-ROS (Sopapa & Viridio)! Ya tenemos la base de datos MySQL conectada y el feed 100% dinámico. 🚀🔥', NOW() - INTERVAL 2 HOUR, 5),
(2, 'Amir', 'img/mesi.jpg', '¡Alta sesión de skate hoy clavando los mejores trucos! ¿Quién se suma a unas partidas de Gun 2.0 y Minecraft 3 más tarde? 🛹🎮', NOW() - INTERVAL 1 HOUR, 8)
ON DUPLICATE KEY UPDATE `contenido` = VALUES(`contenido`);

-- Insertar registros
INSERT INTO `registro` (`id_usuario`, `correo`) VALUES
(1, 'ulises@cp-ros.com'),
(2, 'amir@cp-ros.com')
ON DUPLICATE KEY UPDATE `correo` = VALUES(`correo`);
