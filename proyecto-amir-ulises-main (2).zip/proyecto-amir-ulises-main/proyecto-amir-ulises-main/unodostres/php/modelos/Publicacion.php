<?php
/**
 * MODELO: Publicacion
 * Tabla: publicacion (Base de datos: u283509122_cyp)
 * Campos: id_publicacion, id_usuario, contenido, fecha_publicacion, imagen
 *
 * Gestiona las publicaciones del feed dinámico de la red social CP-ROS.
 */

require_once __DIR__ . '/../conexion.php';

class Publicacion {

    /**
     * Obtener el feed principal de publicaciones con datos del autor (nombre y avatar).
     * @param int $limite Cantidad máxima de publicaciones a obtener.
     * @return array Lista de publicaciones ordenadas de más reciente a más antigua.
     */
    public static function obtenerFeed($limite = 20) {
        $db = obtenerConexion();
        if (!$db) return [];

        try {
            // Intentar consultar la tabla `publicacion` o `publicaciones`
            $stmt = $db->prepare(
                "SELECT p.id_publicacion, p.id_usuario, p.contenido, p.fecha_publicacion,
                        COALESCE(p.imagen, '') AS imagen,
                        u.nombre_usuario, u.avatar
                 FROM publicacion p
                 INNER JOIN usuario u ON p.id_usuario = u.id_usuario
                 ORDER BY p.fecha_publicacion DESC, p.id_publicacion DESC
                 LIMIT :limite"
            );
            $stmt->bindValue(':limite', (int)$limite, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll() ?: [];
        } catch (PDOException $e) {
            // Si la tabla publicacion no existe aún o tiene otro nombre, retornar arreglo vacío
            error_log("Error al consultar feed de publicaciones: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Crear una nueva publicación en el feed.
     * @param int $idUsuario ID del autor de la publicación.
     * @param string $contenido Texto de la publicación.
     * @param string|null $imagen Ruta a imagen opcional adjunta.
     * @return int|false ID de la publicación insertada o false si falló.
     */
    public static function crear($idUsuario, $contenido, $imagen = null) {
        $db = obtenerConexion();
        if (!$db) return false;

        try {
            $stmt = $db->prepare(
                "INSERT INTO publicacion (id_usuario, contenido, fecha_publicacion, imagen)
                 VALUES (:id_usuario, :contenido, NOW(), :imagen)"
            );
            $exito = $stmt->execute([
                ':id_usuario' => (int)$idUsuario,
                ':contenido'  => trim($contenido),
                ':imagen'     => $imagen
            ]);

            return $exito ? (int)$db->lastInsertId() : false;
        } catch (PDOException $e) {
            error_log("Error al crear publicación: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Obtener publicaciones realizadas por un usuario específico.
     * @param int $idUsuario
     * @return array
     */
    public static function obtenerPorUsuario($idUsuario) {
        $db = obtenerConexion();
        if (!$db) return [];

        try {
            $stmt = $db->prepare(
                "SELECT p.id_publicacion, p.id_usuario, p.contenido, p.fecha_publicacion,
                        COALESCE(p.imagen, '') AS imagen,
                        u.nombre_usuario, u.avatar
                 FROM publicacion p
                 INNER JOIN usuario u ON p.id_usuario = u.id_usuario
                 WHERE p.id_usuario = :id_usuario
                 ORDER BY p.fecha_publicacion DESC, p.id_publicacion DESC"
            );
            $stmt->execute([':id_usuario' => (int)$idUsuario]);
            return $stmt->fetchAll() ?: [];
        } catch (PDOException $e) {
            error_log("Error al obtener publicaciones del usuario: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Eliminar una publicación verificando que pertenezca al usuario.
     * @param int $idPublicacion
     * @param int $idUsuario
     * @return bool
     */
    public static function eliminar($idPublicacion, $idUsuario) {
        $db = obtenerConexion();
        if (!$db) return false;

        try {
            $stmt = $db->prepare("DELETE FROM publicacion WHERE id_publicacion = :id AND id_usuario = :id_usuario");
            return $stmt->execute([
                ':id'         => (int)$idPublicacion,
                ':id_usuario' => (int)$idUsuario
            ]);
        } catch (PDOException $e) {
            return false;
        }
    }
}
