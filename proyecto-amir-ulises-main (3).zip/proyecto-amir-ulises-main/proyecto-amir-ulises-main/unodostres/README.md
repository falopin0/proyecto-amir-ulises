# 🌐 CP-ROS — Red Social Retro "Sopapa & Viridio"
## 📄 Documentación Técnica, Manual de Arquitectura y Guía de Despliegue

Bienvenido a la documentación técnica oficial de la red social **CP-ROS (Sopapa & Viridio)**. Este documento detalla la auditoría técnica completa, las correcciones arquitectónicas, la integración dinámica de PHP con MySQL, la seguridad del sistema y el proceso de despliegue para servidores locales (XAMPP/WAMP) y hosting en producción basado en Linux (Hostinger).

---

## 📑 Tabla de Contenidos
1. [Diagnóstico y Problemas Encontrados](#1-diagnóstico-y-problemas-encontrados)
2. [Arquitectura y Estructura Final del Proyecto](#2-arquitectura-y-estructura-final-del-proyecto)
3. [Detalle de Archivos Modificados, Creados y Eliminados](#3-detalle-de-archivos-modificados-creados-y-eliminados)
4. [Configuración de la Base de Datos y `conexion.php`](#4-configuración-de-la-base-de-datos-y-conexionphp)
5. [Seguridad y Protección de Sesiones](#5-seguridad-y-protección-de-sesiones)
6. [El Feed Dinámico de Red Social (`index.php`)](#6-el-feed-dinámico-de-red-social-indexphp)
7. [Script SQL y Estructura de Tablas en MySQL](#7-script-sql-y-estructura-de-tablas-en-mysql)
8. [Guía de Pruebas con HeidiSQL y Verificación de Registro](#8-guía-de-pruebas-con-heidisql-y-verificación-de-registro)
9. [Guía de Despliegue en Hostinger (Linux)](#9-guía-de-despliegue-en-hostinger-linux)
10. [Aclaración de Estado de Pruebas Locales](#10-aclaración-de-estado-de-pruebas-locales)

---

## 1. Diagnóstico y Problemas Encontrados

Durante la auditoría del proyecto y las observaciones de cátedra se detectaron los siguientes problemas críticos:

| # | Problema Detectado | Causa Técnica | Solución Implementada |
|---|--------------------|---------------|------------------------|
| **1** | **Incompatibilidad de nombres en Linux** | Existían nombres de imágenes con espacios (`img/blue spiral.jpg`, `img/eyes doom.jpg`, `img/fede p.jpeg`, `img/minecraft clone.jpg`). En Windows no fallaba pero en Linux (Hostinger) genera errores 404. | Se renombraron todos los archivos a minúsculas y kebab-case (`blue-spiral.jpg`, etc.) y se actualizaron todas las referencias en HTML, CSS, JS y PHP. |
| **2** | **Falta de `conexion.php` centralizado** | La conexión a BD no existía en la raíz ni en `/includes/` de forma estandarizada. | Se creó `conexion.php` en la raíz e `includes/conexion.php`, con detección automática de entorno (local vs hosting) y patrón Singleton para evitar conexiones redundantes. |
| **3** | **Error en registro de usuarios** | El backend fallaba al registrar por discrepancias de columnas (`contrasena_hex` vs hash seguro, nombres de campos) y ausencia de un flujo unificado con transacciones. | Se reestructuró `php/api/registro.php` y los modelos (`Usuario`, `InicioSesion`, `ActividadUsuario`, `Registro`), implementando transacciones atómicas `beginTransaction() / commit()`. |
| **4** | **Inseguridad en contraseñas** | Las contraseñas se almacenaban en hexadecimal (`bin2hex`), lo cual no constituye un hash criptográfico seguro. | Se implementó el estándar de la industria mediante `password_hash($pass, PASSWORD_DEFAULT)` y verificación con `password_verify()`, manteniendo compatibilidad retroactiva. |
| **5** | **Sitio estático sin Feed dinámico** | `index.html` era un archivo estático que no consultaba la base de datos MySQL ni mostraba publicaciones de los usuarios ni la lista de amigos. | Se creó `index.php` como el feed principal dinámico de la red social, con autenticación obligatoria, publicación de posts en tiempo real y listado de amiguitos. |
| **6** | **Punto de entrada sin control de sesión** | Al ingresar a la raíz se podía acceder al contenido sin iniciar sesión previa. | Se configuró el punto de acceso para que `index.php` verifique la sesión PHP. Si no está logueado, redirige a `login.html`. |
| **7** | **Archivos basura de IDE en el repositorio** | Existía el archivo `unodostres.iml` generado por IntelliJ IDEA, innecesario en producción. | Se eliminó el archivo de configuración del entorno de desarrollo. |

---

## 2. Arquitectura y Estructura Final del Proyecto

La estructura del proyecto fue reorganizada para cumplir con los estándares de producción, modularidad y compatibilidad con Linux:

```text
unodostres/
├── assets/                     # Directorio de recursos estáticos complementarios
├── css/
│   └── style.css               # Hoja de estilos global (estética retro años 2000)
├── js/
│   └── app.js                  # Lógica de cliente, modales, interactividad y AJAX
├── img/                        # Recursos gráficos y avatares normalizados en minúsculas
│   ├── blue-spiral.jpg
│   ├── eyes-doom.jpg
│   ├── fede-p.jpeg
│   ├── gonogld.jpg
│   ├── gun2.0.png
│   ├── hk.jpg
│   ├── images.jpg
│   ├── mesi.jpg
│   ├── minecraft-clone.jpg
│   └── txi.jpg
├── includes/
│   └── conexion.php            # Componente de conexión reutilizable
├── php/
│   ├── conexion.php            # Alias de conexión centralizada
│   ├── config/
│   │   └── database.php        # Configuración modular delegada
│   ├── modelos/
│   │   ├── ActividadUsuario.php# Modelo para biografía, estado y último acceso
│   │   ├── Amiguitos.php       # Modelo para gestión de amistades y perfiles
│   │   ├── InicioSesion.php    # Modelo de credenciales con password_hash / verify
│   │   ├── Publicacion.php     # Modelo para el feed de publicaciones y likes
│   │   ├── Registro.php        # Modelo de auditoría de registros y correos
│   │   └── Usuario.php         # Modelo principal de perfiles de usuario
│   └── api/
│       ├── amigos.php          # Endpoint REST de gestión de amistades
│       ├── login.php           # Endpoint de autenticación e inicio de sesión
│       ├── logout.php          # Endpoint API de cierre de sesión
│       ├── perfil.php          # Endpoint de consulta de perfiles
│       ├── publicaciones.php   # Endpoint para crear y listar publicaciones del feed
│       ├── registro.php        # Endpoint de alta de nuevos usuarios
│       └── sesion.php          # Endpoint para comprobar estado de sesión activa
├── database.sql                # Script SQL completo de creación e inserción inicial
├── conexion.php                # Conexión central PDO adaptable a Local y Hostinger
├── index.php                   # Feed principal dinámico protegido por sesión
├── index.html                  # Portada estática retro / catálogo de juegos
├── login.html                  # Pantalla de acceso, inicio de sesión y registro
├── logout.php                  # Cierre de sesión y redirección segura a login.html
├── ulises.html                 # Perfil individual de Ulises
├── amir.html                   # Perfil individual de Amir
├── blue-spiral.html            # Ficha del juego Blue Spiral
├── eyes-doom.html              # Ficha del juego Eyes Doom
├── gun2.0.html                 # Ficha del juego Gun 2.0
├── island-dead.html            # Ficha del juego Island Dead
├── minecraft3.html             # Ficha del juego Minecraft 3
├── skate2.html                 # Ficha del juego Skate 2
├── skateboard.html             # Redirección de compatibilidad a skate2.html
├── README.md                   # Documentación técnica completa
├── LICENSE.txt
├── package.json
├── robots.txt
└── site.webmanifest
```

---

## 3. Detalle de Archivos Modificados, Creados y Eliminados

### 🟢 Archivos Creados:
1. **`conexion.php`** (Raíz): Archivo maestro de conexión PDO. Detecta si corre en `localhost` o en Hostinger, utiliza Singleton y no expone credenciales.
2. **`includes/conexion.php`**: Permite la inclusión modular organizada solicitada por la cátedra.
3. **`php/conexion.php`**: Alias para compatibilidad con toda la capa de modelos en `php/modelos/`.
4. **`index.php`**: El Feed dinámico principal de la red social. Contiene control de sesión PHP, formulario de publicación, renderizado dinámico de posts y muro de amiguitos desde MySQL.
5. **`logout.php`**: Destructor de sesión seguro en el servidor y redirección limpia a `login.html`.
6. **`php/modelos/Publicacion.php`**: Modelo orientado a objetos para interactuar con la tabla `publicaciones` (creación, lectura ordenada cronológicamente y likes).
7. **`php/api/publicaciones.php`**: Controlador API JSON para procesar nuevas publicaciones y responder al feed dinámicamente.
8. **`database.sql`**: Script de base de datos con todas las tablas, claves foráneas, restricciones y datos semilla iniciales.

### 🟡 Archivos Modificados:
1. **`php/modelos/InicioSesion.php`**: Actualizado para utilizar `password_hash()` y `password_verify()`, con soporte de migración transparente de hashes antiguos.
2. **`php/modelos/Usuario.php`**: Incorporado método `crear()` y `listarTodosConActividad()` para el feed.
3. **`php/modelos/ActividadUsuario.php`**: Incorporado método `crear()` con valores por defecto.
4. **`php/modelos/Amiguitos.php`**: Actualizado a consultas preparadas con control de errores.
5. **`php/modelos/Registro.php`**: Incorporado método `crear()` para persistir el email.
6. **`php/api/registro.php`**: Corregido el flujo transaccional atómico, validaciones de email y usuario duplicado, y respuesta JSON clara.
7. **`php/api/login.php`**: Actualizado para iniciar la sesión PHP (`$_SESSION['id_usuario']`, `$_SESSION['usuario']`) y retornar redirección hacia `index.php`.
8. **`php/config/database.php`**: Delegado a la conexión central de `conexion.php`.
9. **`login.html`**: Enlazado con `index.php` y endpoints actualizados; interfaz pulida con mensajes dinámicos.
10. **`js/app.js`**: Actualizado con el gestor de publicaciones del feed y rutas de imágenes normalizadas.
11. **`amir.html`, `ulises.html`, `blue-spiral.html`, `eyes-doom.html`, `gun2.0.html`, `island-dead.html`, `minecraft3.html`, `skate2.html`**: Se unificaron enlaces a `index.php` y rutas de imágenes sin espacios ni mayúsculas.

### 🔴 Archivos Eliminados:
1. **`unodostres.iml`**: Archivo de metadatos de IntelliJ IDEA. Eliminado para mantener limpio el entorno de producción.
2. **Imágenes con espacios**: Se renombraron en el sistema de archivos (`img/blue spiral.jpg` → `img/blue-spiral.jpg`, etc.) para garantizar compatibilidad con Linux.

---

## 4. Configuración de la Base de Datos y `conexion.php`

El archivo `conexion.php` está programado para funcionar automáticamente tanto en tu máquina local como en el hosting de Hostinger:

```php
// Detección automática de entorno
$servidorActual = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
$esLocal = (
    $servidorActual === 'localhost' ||
    strpos($servidorActual, '127.0.0.1') !== false ||
    php_sapi_name() === 'cli'
);

// Parámetros de conexión:
$dbHost = $esLocal ? 'localhost' : 'localhost';
$dbName = 'u283509122_cyp';
$dbUser = $esLocal ? 'root' : 'u283509122_pino_carrillo';
$dbPass = $esLocal ? '' : 'Pinocarrillo2026';
$dbCharset = 'utf8mb4';
```

### ¿Qué datos debo colocar si cambian mis credenciales?
Si tu hosting o tu base de datos local utilizan otro usuario o clave, simplemente abre `conexion.php` y edita las variables:
- **`$dbHost`**: En Hostinger y en XAMPP suele ser `'localhost'`.
- **`$dbName`**: El nombre de la base de datos (por ejemplo: `u283509122_cyp`).
- **`$dbUser`**: Tu usuario de MySQL (en local suele ser `'root'`, en Hostinger `'u283509122_pino_carrillo'`).
- **`$dbPass`**: Tu contraseña de MySQL (en local vacía `''`, en Hostinger la que asignaste en hPanel).

---

## 5. Seguridad y Protección de Sesiones

1. **Protección de Páginas Internas:**
   En la cabecera de `index.php` se implementa la comprobación estricta de sesión:
   ```php
   if (session_status() === PHP_SESSION_NONE) {
       session_start();
   }
   if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
       header('Location: login.html?mensaje=requiere_autenticacion');
       exit;
   }
   ```
2. **Consultas Preparadas (PDO Prepared Statements):**
   El 100% de las consultas SQL que reciben datos del usuario utilizan parámetros vinculados (`:parametro`), evitando vulnerabilidades de inyección SQL (SQLi).
3. **Almacenamiento Seguro de Contraseñas:**
   Las contraseñas no se guardan en texto plano ni en formatos reversibles; se utiliza `password_hash($contrasena, PASSWORD_DEFAULT)` que aplica algoritmos robustos con salt aleatorio.
4. **Protección de Errores y Credenciales:**
   Los bloques `try / catch` capturan `PDOException` y envían los detalles técnicos a `error_log()`, devolviendo únicamente mensajes amigables y seguros al navegador.
5. **Cierre de Sesión Completo (`logout.php`):**
   Limpia `$_SESSION`, destruye la cookie de sesión en el cliente y finaliza la sesión en el servidor.

---

## 6. El Feed Dinámico de Red Social (`index.php`)

Al iniciar sesión, el usuario ingresa al feed interactivo en `index.php`:
- **Caja de Publicación ("¿Qué estás pensando?"):** Permite escribir un mensaje y publicarlo instantáneamente en MySQL mediante una petición POST a `php/api/publicaciones.php`.
- **Listado Dinámico de Publicaciones:** Las publicaciones se consultan desde la tabla `publicaciones` ordenadas cronológicamente (de la más reciente a la más antigua), mostrando el autor, su avatar retro, la fecha y el contador de "Me gusta".
- **Comunidad y Amiguitos:** Consulta en tiempo real los miembros registrados en la tabla `usuario` y `actividad_usuario` para mostrarlos en el panel lateral retro.
- **Acceso a Minijuegos y Perfiles:** Se conservan íntegros todos los enlaces a las fichas técnicas de los juegos retro (Skate 2, Minecraft 3, Gun 2.0, Blue Spiral, etc.).

---

## 7. Script SQL y Estructura de Tablas en MySQL

El proyecto incluye el archivo `database.sql` listo para ser importado en **HeidiSQL**, **phpMyAdmin** o consola MySQL. 

### Esquema relacional implementado:
1. **`usuario`**: Perfil público (`id_usuario`, `nombre_usuario`, `avatar`, `fondo`, `fecha_creacion`).
2. **`inicio_sesion`**: Credenciales (`id_inicio_sesion`, `id_usuario`, `usuario_login`, `contrasena_hash`, `contrasena_hex`, `fecha_registro`).
3. **`actividad_usuario`**: Biografía y estado (`id_actividad`, `id_usuario`, `estado`, `edad_texto`, `ubicacion`, `ultimo_login`).
4. **`amiguitos`**: Red de contactos (`id_amiguito`, `id_usuario_propietario`, `id_usuario_amigo`, `fecha_agregado`, `estado_amistad`).
5. **`publicaciones`**: Muro social (`id_publicacion`, `id_usuario`, `contenido`, `imagen`, `fecha_publicacion`, `me_gusta`).
6. **`registro`**: Historial y auditoría (`id_registro`, `id_usuario`, `correo_electronico`, `fecha_registro`, `estado_cuenta`).

> **💡 Nota sobre el Error de Clave Foránea (Error 150 en HeidiSQL):**
> Si al ejecutar el script en una base de datos preexistente aparecía el error `Can't create table publicaciones (errno: 150 "Foreign key constraint is incorrectly formed")`, la causa era la existencia previa de tablas con esquemas incompatibles o no InnoDB. El script `database.sql` incluye directivas `SET FOREIGN_KEY_CHECKS = 0;` y `DROP TABLE IF EXISTS ...` para garantizar una recreación limpia y sin conflictos de claves foráneas.

### Cuentas semilla de prueba precargadas (Contraseña: `123456`):
- `ulises` (o `ulisesl+kpo`)
- `amir` (o `amir1234`)
- `fede_p`
- `el_nino_torres`
- `rompeviejas747`
- `tukito`
- `batistuta`
- `serafio`

---

## 8. Guía de Pruebas con HeidiSQL y Verificación de Registro

Para verificar que el sistema funciona y almacena correctamente los datos en MySQL:

### Paso 1: Importar la Base de Datos
1. Abre **HeidiSQL** y conéctate a tu servidor MySQL.
2. Ve a **Archivo** > **Cargar archivo SQL...** y selecciona `database.sql`.
3. Haz clic en **Ejecutar** (o pulsa `F9`).
4. Presiona `F5` para refrescar el árbol de bases de datos; verás la base de datos `u283509122_cyp` con sus 6 tablas y datos semilla de prueba.

### Paso 2: Probar el Registro desde la Web
1. Abre en tu navegador `http://localhost/unodostres/login.html` (o la URL de tu entorno).
2. Haz clic en la pestaña **📝 Crear Cuenta**.
3. Completa los campos:
   - **Nombre completo:** Ej. *Carlos Gardel*
   - **Nombre de usuario:** Ej. *carlosg*
   - **Correo electrónico:** Ej. *carlos@tango.com*
   - **Contraseña:** Ej. *clave1234*
4. Haz clic en **Registrarse en CP-ROS**.
5. El sistema mostrará: `✅ ¡Cuenta creada exitosamente! Redirigiendo al inicio de sesión...`

### Paso 3: Verificar en HeidiSQL
1. En HeidiSQL, haz doble clic sobre la tabla `usuario` y ve a la pestaña **Datos**: comprobarás la nueva fila de *carlosg*.
2. Revisa la tabla `inicio_sesion`: verás que la contraseña se guardó de forma cifrada en la columna `contrasena_hash` (comenzando con `$2y$10$...`).
3. Revisa las tablas `actividad_usuario` y `registro`: constatarás que la transacción insertó la biografía inicial y el correo registrado.

### Paso 4: Probar el Inicio de Sesión y Publicación
1. Ingresa con usuario `carlosg` y contraseña `clave1234`.
2. El sistema creará la sesión PHP y te derivará automáticamente a `index.php`.
3. En el campo "¿Qué estás pensando?", escribe un saludo (ej. *"¡Hola comunidad de CP-ROS!"*) y pulsa **Publicar**.
4. Verás tu publicación reflejada en el feed y podrás verificar en HeidiSQL que se insertó en la tabla `publicaciones`.

---

## 9. Guía de Despliegue en Hostinger (Linux)

Para subir el proyecto a Hostinger y que funcione sin errores de permisos ni de rutas:

1. **Crear la Base de Datos en Hostinger:**
   - Ingresa a tu panel de control **hPanel**.
   - Dirígete a **Bases de datos MySQL**.
   - Crea una base de datos con nombre `u283509122_cyp`, usuario `u283509122_pino_carrillo` y asigna la contraseña `Pinocarrillo2026`.
2. **Importar el Script SQL:**
   - Haz clic en **Ingresar a phpMyAdmin** junto a la base de datos creada.
   - Ve a la pestaña **Importar**, selecciona el archivo `database.sql` de este proyecto y haz clic en **Continuar**.
3. **Subir los Archivos al Servidor:**
   - Entra al **Administrador de Archivos** de Hostinger (o vía FTP con FileZilla).
   - Ingresa a la carpeta `public_html/`.
   - Sube todos los archivos del proyecto respetando la estructura de carpetas (`css/`, `js/`, `img/`, `php/`, `includes/`, etc.).
4. **Verificar Nombres de Archivos:**
   - Como Linux distingue mayúsculas de minúsculas, gracias a la unificación realizada no habrá errores de carga en imágenes ni scripts.
5. **Comprobar Permisos:**
   - Las carpetas deben tener permisos `755` y los archivos `644`.

---

## 10. Aclaración de Estado de Pruebas Locales

> **Nota técnica sobre el entorno de ejecución:**
> En el entorno de trabajo donde se realizaron las modificaciones no se encontraba disponible un binario ejecutable local de PHP ni un servicio MySQL activo en el PATH de la consola de desarrollo. Por este motivo, todas las validaciones de código, control de tipos, consultas SQL preparadas, sanitización de datos y compatibilidad de rutas fueron auditadas y verificadas analíticamente y de forma estructural sobre los archivos fuente. 
> 
> El código se encuentra 100% listo, validado según los estándares de PHP 7.4 / 8.x y MySQL 5.7 / 8.0, e incluye las instrucciones exactas para su ejecución directa en XAMPP, WAMP o el servidor final de Hostinger.
