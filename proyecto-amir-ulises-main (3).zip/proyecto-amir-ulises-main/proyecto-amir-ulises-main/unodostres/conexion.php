<?php
/**
 * ARCHIVO CENTRAL DE CONEXIÓN A LA BASE DE DATOS: conexion.php
 * Red Social "CP-ROS" — Sopapa & Viridio
 *
 * Establece la conexión entre PHP y MySQL mediante PDO de forma segura,
 * optimizada y reutilizable.
 *
 * Características:
 * - Compatible tanto con entorno local (XAMPP / WAMP / Docker / Localhost)
 *   como con hosting de producción en Linux (Hostinger).
 * - Patrón Singleton para evitar conexiones duplicadas e innecesarias.
 * - Manejo de excepciones PDO y registro seguro en error_log (sin exponer credenciales).
 * - Soporte completo de UTF-8 (utf8mb4) para emojis, tildes y caracteres especiales.
 */

// ============================================================================
// CONFIGURACIÓN DE PARÁMETROS SEGÚN EL ENTORNO (LOCAL / HOSTING)
// ============================================================================
if (!defined('DB_CONFIG_CARGADA')) {
    define('DB_CONFIG_CARGADA', true);

    // Detectar si estamos en un entorno local o de producción
    $servidorActual = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : (isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'localhost');
    $esLocal = (
        $servidorActual === 'localhost' ||
        strpos($servidorActual, '127.0.0.1') !== false ||
        strpos($servidorActual, '::1') !== false ||
        php_sapi_name() === 'cli'
    );

    // Parámetros de base de datos
    // Permite sobreescritura mediante variables de entorno si están disponibles
    $dbHost = getenv('DB_HOST') ?: ($esLocal ? 'localhost' : 'localhost');
    $dbName = getenv('DB_NAME') ?: 'u283509122_cyp';
    $dbUser = getenv('DB_USER') ?: ($esLocal ? 'root' : 'u283509122_pino_carrillo');
    $dbPass = getenv('DB_PASS') ?: ($esLocal ? '' : 'Pinocarrillo2026');
    $dbCharset = 'utf8mb4';

    if (!defined('DB_HOST'))    define('DB_HOST', $dbHost);
    if (!defined('DB_NAME'))    define('DB_NAME', $dbName);
    if (!defined('DB_USER'))    define('DB_USER', $dbUser);
    if (!defined('DB_PASS'))    define('DB_PASS', $dbPass);
    if (!defined('DB_CHARSET')) define('DB_CHARSET', $dbCharset);
}

/**
 * Función centralizada para obtener una instancia única (reutilizable) de conexión PDO.
 * Evita abrir múltiples conexiones a MySQL en una misma petición HTTP.
 *
 * @return PDO|null Instancia de conexión PDO activa, o null si falla.
 */
function obtenerConexion() {
    static $conexionInstancia = null;

    if ($conexionInstancia !== null) {
        return $conexionInstancia;
    }

    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;

        $opciones = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
        ];

        $conexionInstancia = new PDO($dsn, DB_USER, DB_PASS, $opciones);
        return $conexionInstancia;

    } catch (PDOException $e) {
        // En local, intentar conectar con usuario root sin contraseña si falló el usuario de hosting
        if (defined('DB_USER') && DB_USER !== 'root') {
            try {
                $dsnLocal = "mysql:host=localhost;dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
                $opcionesLocal = [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ];
                $conexionInstancia = new PDO($dsnLocal, 'root', '', $opcionesLocal);
                return $conexionInstancia;
            } catch (PDOException $e2) {
                // Si también falla, registrar el error técnico internamente
            }
        }

        // Registrar error en log del servidor sin exponer datos sensibles al cliente
        error_log("[CP-ROS] Error de conexión a la base de datos: " . $e->getMessage());

        // Si es una petición de API JSON, responder con error controlado
        $esApi = (
            (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) ||
            (isset($_SERVER['REQUEST_URI']) && strpos($_SERVER['REQUEST_URI'], '/api/') !== false)
        );

        if ($esApi) {
            if (!headers_sent()) {
                http_response_code(500);
                header('Content-Type: application/json; charset=utf-8');
            }
            echo json_encode([
                'exito'   => false,
                'mensaje' => 'Error de conexión con la base de datos. Verifique que el servicio MySQL esté activo.'
            ]);
            exit;
        }

        return null;
    }
}

// Variable global de conexión disponible para scripts que la requieran directamente
$conexion = obtenerConexion();
$db = $conexion;
