-- ============================================================================
-- SCRIPT DE BASE DE DATOS: u283509122_cyp
-- Red Social "CP-ROS" — Sopapa & Viridio
-- Compatible con MySQL 5.7+, MySQL 8.0+, MariaDB y HeidiSQL / phpMyAdmin
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `u283509122_cyp` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `u283509122_cyp`;

-- Desactivar temporalmente revisión de claves foráneas para eliminación y creación limpia
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- ELIMINACIÓN DE TABLAS PREVIAS (Para evitar error 150 por esquemas incompatibles)
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `publicaciones`;
DROP TABLE IF EXISTS `publicacion`;
DROP TABLE IF EXISTS `amiguitos`;
DROP TABLE IF EXISTS `actividad_usuario`;
DROP TABLE IF EXISTS `inicio_sesion`;
DROP TABLE IF EXISTS `registro`;
DROP TABLE IF EXISTS `usuario`;

-- ----------------------------------------------------------------------------
-- 1. TABLA: usuario (Perfiles principales de la red social)
-- ----------------------------------------------------------------------------
CREATE TABLE `usuario` (
  `id_usuario` INT NOT NULL AUTO_INCREMENT,
  `nombre_usuario` VARCHAR(100) NOT NULL,
  `avatar` VARCHAR(255) NOT NULL DEFAULT 'img/images.jpg',
  `fondo` VARCHAR(255) NOT NULL DEFAULT '',
  `fecha_creacion` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `uk_usuario_nombre` (`nombre_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 2. TABLA: inicio_sesion (Credenciales de acceso con contraseñas seguras)
-- ----------------------------------------------------------------------------
CREATE TABLE `inicio_sesion` (
  `id_inicio_sesion` INT NOT NULL AUTO_INCREMENT,
  `id_usuario` INT NOT NULL,
  `usuario_login` VARCHAR(100) NOT NULL,
  `contrasena_hash` VARCHAR(255) NOT NULL,
  `contrasena_hex` VARCHAR(255) DEFAULT NULL,
  `fecha_registro` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_inicio_sesion`),
  UNIQUE KEY `uk_iniciosesion_login` (`usuario_login`),
  KEY `idx_iniciosesion_usuario` (`id_usuario`),
  CONSTRAINT `fk_iniciosesion_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3. TABLA: actividad_usuario (Información biográfica, estado y último acceso)
-- ----------------------------------------------------------------------------
CREATE TABLE `actividad_usuario` (
  `id_actividad` INT NOT NULL AUTO_INCREMENT,
  `id_usuario` INT NOT NULL,
  `estado` VARCHAR(255) NOT NULL DEFAULT '¡Hola! Estoy usando CP-ROS.',
  `edad_texto` VARCHAR(50) NOT NULL DEFAULT '20 años',
  `ubicacion` VARCHAR(100) NOT NULL DEFAULT 'Buenos Aires, Argentina',
  `ultimo_login` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_actividad`),
  KEY `idx_actividad_usuario` (`id_usuario`),
  CONSTRAINT `fk_actividad_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 4. TABLA: amiguitos (Lista de amigos y relaciones de amistad)
-- ----------------------------------------------------------------------------
CREATE TABLE `amiguitos` (
  `id_amiguito` INT NOT NULL AUTO_INCREMENT,
  `id_usuario_propietario` INT NOT NULL,
  `id_usuario_amigo` INT NOT NULL,
  `fecha_agregado` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `estado_amistad` VARCHAR(20) NOT NULL DEFAULT 'aceptado',
  PRIMARY KEY (`id_amiguito`),
  KEY `idx_amiguitos_propietario` (`id_usuario_propietario`),
  KEY `idx_amiguitos_amigo` (`id_usuario_amigo`),
  CONSTRAINT `fk_amiguitos_propietario` FOREIGN KEY (`id_usuario_propietario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_amiguitos_amigo` FOREIGN KEY (`id_usuario_amigo`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 5. TABLA: publicaciones (Publicaciones dinámicas en el feed de la comunidad)
-- ----------------------------------------------------------------------------
CREATE TABLE `publicaciones` (
  `id_publicacion` INT NOT NULL AUTO_INCREMENT,
  `id_usuario` INT NOT NULL,
  `contenido` TEXT NOT NULL,
  `imagen` VARCHAR(255) DEFAULT NULL,
  `fecha_publicacion` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `me_gusta` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_publicacion`),
  KEY `idx_publicaciones_usuario` (`id_usuario`),
  CONSTRAINT `fk_publicaciones_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 6. TABLA: registro (Historial de altas y correos electrónicos)
-- ----------------------------------------------------------------------------
CREATE TABLE `registro` (
  `id_registro` INT NOT NULL AUTO_INCREMENT,
  `id_usuario` INT NOT NULL,
  `correo_electronico` VARCHAR(150) NOT NULL,
  `fecha_registro` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `estado_cuenta` VARCHAR(50) NOT NULL DEFAULT 'activa',
  PRIMARY KEY (`id_registro`),
  UNIQUE KEY `uk_registro_correo` (`correo_electronico`),
  KEY `idx_registro_usuario` (`id_usuario`),
  CONSTRAINT `fk_registro_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================================
-- DATOS INICIALES POR DEFECTO (SEED / PRUEBAS)
-- Credenciales de prueba:
--   Usuario: ulises (o ulisesl+kpo)  | Clave: 123456 (o 12345)
--   Usuario: amir   (o amir1234)     | Clave: 123456 (o 12345)
--   Usuario: fedep                   | Clave: 123456
--   Usuario: tukito                  | Clave: 123456
-- ============================================================================

-- 1. Insertar usuarios iniciales
INSERT INTO `usuario` (`id_usuario`, `nombre_usuario`, `avatar`, `fondo`) VALUES
(1, 'ulises', 'img/txi.jpg', 'img/gun2.0.png'),
(2, 'amir', 'img/mesi.jpg', 'img/fede-p.jpeg'),
(3, 'fede_p', 'img/fede-p.jpeg', 'img/blue-spiral.jpg'),
(4, 'el_nino_torres', 'img/hk.jpg', 'img/eyes-doom.jpg'),
(5, 'rompeviejas747', 'img/images.jpg', 'img/minecraft-clone.jpg'),
(6, 'tukito', 'img/gonogld.jpg', 'img/gun2.0.png'),
(7, 'batistuta', 'img/blue-spiral.jpg', ''),
(8, 'serafio', 'img/eyes-doom.jpg', '');

-- 2. Insertar credenciales de acceso (Contraseña '123456' y '12345', hash Bcrypt + hex)
INSERT INTO `inicio_sesion` (`id_usuario`, `usuario_login`, `contrasena_hash`, `contrasena_hex`) VALUES
(1, 'ulises', '$2y$10$wN3oB.u.F7kY9w9lX7n0.e181V74i98G74j5qV7s7z1wGZ348Q20C', '313233343536'),
(2, 'amir', '$2y$10$wN3oB.u.F7kY9w9lX7n0.e181V74i98G74j5qV7s7z1wGZ348Q20C', '313233343536'),
(3, 'fede_p', '$2y$10$wN3oB.u.F7kY9w9lX7n0.e181V74i98G74j5qV7s7z1wGZ348Q20C', '313233343536'),
(4, 'el_nino_torres', '$2y$10$wN3oB.u.F7kY9w9lX7n0.e181V74i98G74j5qV7s7z1wGZ348Q20C', '313233343536'),
(5, 'rompeviejas747', '$2y$10$wN3oB.u.F7kY9w9lX7n0.e181V74i98G74j5qV7s7z1wGZ348Q20C', '313233343536'),
(6, 'tukito', '$2y$10$wN3oB.u.F7kY9w9lX7n0.e181V74i98G74j5qV7s7z1wGZ348Q20C', '313233343536'),
(7, 'batistuta', '$2y$10$wN3oB.u.F7kY9w9lX7n0.e181V74i98G74j5qV7s7z1wGZ348Q20C', '313233343536'),
(8, 'serafio', '$2y$10$wN3oB.u.F7kY9w9lX7n0.e181V74i98G74j5qV7s7z1wGZ348Q20C', '313233343536');

-- 3. Insertar datos de actividad / biografía
INSERT INTO `actividad_usuario` (`id_usuario`, `estado`, `edad_texto`, `ubicacion`) VALUES
(1, 'Subiendo de rango en Minecraft y armando partidas retro 🎮', '18 años', 'tucuman, tero violado'),
(2, 'Clavando un switch half-cab heelflip en Lyon 25 🛹', '18 Años', 'Gral. Roca'),
(3, 'Listo para unas partidas de Blue Spiral y Gun 2.0 🎯', '19 años', 'Buenos Aires, Argentina'),
(4, 'Defendiendo el Bunker en Island Dead con el equipo 🧟', '20 años', 'Madrid, España'),
(5, 'Construyendo el castillo flotante en Minecraft 3 🏰', '22 años', 'Rosario, Argentina'),
(6, 'Racha de 25 bajas en Gun 2.0 y nuevo récord 🔫', '18 años', 'Córdoba, Argentina'),
(7, 'El Sargento Batistuta presente en la red social ⚽', '25 años', 'Santa Fe, Argentina'),
(8, 'Entrenando en Skate 2 para desbloquear la tabla legendaria 🛹', '21 años', 'Mendoza, Argentina');

-- 4. Insertar relaciones de amigos (Amiguitos)
INSERT INTO `amiguitos` (`id_usuario_propietario`, `id_usuario_amigo`, `estado_amistad`) VALUES
(1, 2, 'aceptado'),
(1, 3, 'aceptado'),
(1, 4, 'aceptado'),
(1, 6, 'aceptado'),
(2, 1, 'aceptado'),
(2, 3, 'aceptado'),
(2, 5, 'aceptado'),
(2, 7, 'aceptado'),
(3, 1, 'aceptado'),
(3, 2, 'aceptado'),
(4, 1, 'aceptado'),
(6, 1, 'aceptado');

-- 5. Insertar publicaciones iniciales en el Feed
INSERT INTO `publicaciones` (`id_usuario`, `contenido`, `imagen`, `fecha_publicacion`, `me_gusta`) VALUES
(1, '¡Bienvenidos a todos a CP-ROS (Sopapa & Viridio)! La red social está 100% conectada a MySQL con feed dinámico y sesiones activas. 🚀🔥', NULL, NOW() - INTERVAL 3 HOUR, 12),
(2, '¡Alta sesión de skate hoy clavando los mejores trucos! ¿Quién se suma a unas partidas de Gun 2.0 y Minecraft 3 más tarde? 🛹🎮', NULL, NOW() - INTERVAL 2 HOUR, 8),
(3, 'Víboras Negras listas para el torneo de Blue Spiral. ¡Dejen sus comentarios si quieren unirse al escuadrón! 🐉⚡', NULL, NOW() - INTERVAL 90 MINUTE, 5),
(6, 'Racha desbloqueada en Gun 2.0 con el Subfusil Láser de Plasma MK-II. ¡Imparable! 🔫🔥', NULL, NOW() - INTERVAL 45 MINUTE, 7),
(4, 'El Wither de Diamante cayó en el End. Ya tenemos la Armadura de Netherite Legendaria forjada. ⚔️💎', NULL, NOW() - INTERVAL 15 MINUTE, 10);

-- 6. Insertar registros de cuenta
INSERT INTO `registro` (`id_usuario`, `correo_electronico`, `estado_cuenta`) VALUES
(1, 'ulises@cp-ros.com', 'activa'),
(2, 'amir@cp-ros.com', 'activa'),
(3, 'fedep@cp-ros.com', 'activa'),
(4, 'ninotorres@cp-ros.com', 'activa'),
(5, 'rompeviejas747@cp-ros.com', 'activa'),
(6, 'tukito@cp-ros.com', 'activa'),
(7, 'batistuta@cp-ros.com', 'activa'),
(8, 'serafio@cp-ros.com', 'activa');
