<?php
/**
 * INCLUDES: conexion.php
 * Proporciona acceso a la conexión centralizada de base de datos de CP-ROS.
 */
require_once __DIR__ . '/../conexion.php';
