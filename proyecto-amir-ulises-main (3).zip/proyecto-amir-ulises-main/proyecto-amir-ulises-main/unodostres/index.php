<?php
/**
 * FEED PRINCIPAL DE LA RED SOCIAL: index.php
 * Red Social "CP-ROS" — Sopapa & Viridio
 *
 * Este archivo funciona como el Feed dinámico de la comunidad (estilo red social retro / Facebook años 2000):
 * 1. Control de acceso mediante sesiones PHP: Si el usuario no ha iniciado sesión, es redirigido a login.html.
 * 2. Muro interactivo para publicar nuevos estados ("¿Qué estás pensando?").
 * 3. Renderizado dinámico de publicaciones reales obtenidas de la base de datos MySQL (tabla: publicaciones).
 * 4. Listado dinámico de los "Amiguitos" registrados y su estado biográfico (tablas: usuario, actividad_usuario).
 * 5. Conservación de la estética visual retro, ventanas modales y accesos a juegos de la plataforma.
 */

// Iniciar sesión PHP para control de acceso
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Comprobar autenticación de usuario
$usuarioAutenticado = false;
$idUsuarioActual = null;
$nombreUsuarioActual = 'Visitante';
$avatarUsuarioActual = 'img/images.jpg';

if (isset($_SESSION['id_usuario']) && !empty($_SESSION['id_usuario'])) {
    $usuarioAutenticado = true;
    $idUsuarioActual = $_SESSION['id_usuario'];
    $nombreUsuarioActual = isset($_SESSION['usuario']) ? $_SESSION['usuario'] : 'Usuario';
    if (isset($_SESSION['avatar']) && !empty($_SESSION['avatar'])) {
        $avatarUsuarioActual = $_SESSION['avatar'];
    }
} else {
    // Si no está autenticado, redirigir al login
    header('Location: login.html?mensaje=requiere_autenticacion');
    exit;
}

// Requerir conexión a la base de datos y modelos
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/php/modelos/Publicacion.php';
require_once __DIR__ . '/php/modelos/Usuario.php';

// Obtener publicaciones reales de la base de datos
$publicaciones = Publicacion::listarRecientes(25);

// Obtener listado de miembros / amiguitos registrados
$amiguitos = Usuario::listarTodosConActividad();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CP-ROS - Feed de la Comunidad</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    /* Estilos complementarios para el feed dinámico */
    .caja-publicar {
      background: #ffffff;
      border: 1px solid #3b5998;
      border-radius: 4px;
      margin-bottom: 20px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .caja-publicar-body {
      padding: 12px;
    }
    .caja-publicar textarea {
      width: 100%;
      box-sizing: border-box;
      height: 75px;
      padding: 8px;
      font-family: Tahoma, Verdana, Arial, sans-serif;
      font-size: 13px;
      border: 1px solid #bdc3c7;
      border-radius: 4px;
      resize: vertical;
      margin-bottom: 8px;
    }
    .caja-publicar-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .publicacion-card {
      background: #fff;
      border: 1px solid #d2d6de;
      border-radius: 4px;
      margin-bottom: 15px;
      padding: 12px;
      box-shadow: 0 1px 2px rgba(0,0,0,0.05);
    }
    .publicacion-header {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 10px;
      border-bottom: 1px dotted #e2e4e8;
      padding-bottom: 8px;
    }
    .publicacion-avatar {
      width: 45px;
      height: 45px;
      border-radius: 4px;
      border: 1px solid #3b5998;
      object-fit: cover;
    }
    .publicacion-autor {
      font-weight: bold;
      color: #3b5998;
      font-size: 14px;
    }
    .publicacion-fecha {
      font-size: 11px;
      color: #777;
    }
    .publicacion-cuerpo {
      font-size: 13px;
      line-height: 1.5;
      color: #2c3e50;
      white-space: pre-wrap;
      word-wrap: break-word;
      margin-bottom: 10px;
    }
    .publicacion-acciones {
      display: flex;
      gap: 15px;
      font-size: 12px;
      border-top: 1px solid #f0f0f0;
      padding-top: 8px;
    }
    .btn-like {
      background: none;
      border: none;
      color: #3b5998;
      font-size: 12px;
      font-weight: bold;
      cursor: pointer;
      padding: 0;
    }
    .btn-like:hover {
      text-decoration: underline;
    }
    .badge-sesion {
      display: inline-block;
      background: #e8f4fd;
      color: #2980b9;
      border: 1px solid #bce8f1;
      border-radius: 3px;
      padding: 3px 8px;
      font-size: 12px;
      margin-bottom: 12px;
    }
  </style>
</head>
<body>

<!-- ==========================================================================
     BARRA SUPERIOR GLOBAL (TOP-BAR)
     ========================================================================== -->
<header class="top-bar">
  <div class="top-bar-left">
    <a href="index.php" title="Inicio de CP-ROS">
      🌐 <span>CP-ROS - © 2026 S&P</span>
    </a>
  </div>
  <div class="top-bar-right">
    <nav class="top-bar-nav" aria-label="Navegación superior">
      <a href="index.php" style="font-weight: bold; color: #fff;">🏠 Feed Principal</a>
      <a href="ulises.html">👤 Perfil Ulises</a>
      <a href="amir.html">👤 Perfil Amir</a>
      <a href="#" class="btn-notificaciones">🔔 Notificaciones <span class="badge-count">3</span></a>
      <a href="#" class="btn-solicitudes">👥 Solicitudes <span class="badge-count">1</span></a>
      <a href="logout.php" id="btn-logout" class="btn-logout" style="background: #c0392b; color: white; padding: 4px 8px; border-radius: 3px; text-decoration: none;">🚪 Cerrar Sesión</a>
    </nav>
  </div>
</header>

<!-- ==========================================================================
     CONTENEDOR PRINCIPAL: FEED DE LA RED SOCIAL
     ========================================================================== -->
<main class="container container-full" style="max-width: 1050px; margin: 20px auto; display: flex; gap: 20px;">

  <!-- COLUMNA IZQUIERDA: MURO DE PUBLICACIONES (FEED) -->
  <section style="flex: 2;">
    
    <div class="badge-sesion">
      👤 Sesión activa: <strong><?php echo htmlspecialchars($nombreUsuarioActual); ?></strong> | Base de datos MySQL conectada
    </div>

    <!-- CAJA DE PUBLICACIÓN DE NUEVO ESTADO -->
    <div class="caja-publicar">
      <div class="caja-header" style="background: #3b5998; color: white; padding: 8px 12px; font-weight: bold; font-size: 13px;">
        ✏️ ¿Qué estás pensando, <?php echo htmlspecialchars($nombreUsuarioActual); ?>?
      </div>
      <div class="caja-publicar-body">
        <form id="form-crear-publicacion" method="POST" action="php/api/publicaciones.php">
          <textarea id="contenido-publicacion" name="contenido" placeholder="Escribe algo para compartir en el muro de CP-ROS..." required></textarea>
          <div class="caja-publicar-footer">
            <span style="font-size: 11px; color: #888;">🌐 Tu publicación será visible en toda la red social.</span>
            <button type="submit" id="btn-enviar-publicacion" style="background: #27ae60; color: white; border: 1px solid #1e8449; padding: 6px 18px; font-size: 13px; font-weight: bold; border-radius: 4px; cursor: pointer;">
              🚀 Publicar
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- SECCIÓN DE FEED DE PUBLICACIONES -->
    <div class="caja">
      <div class="caja-header">
        <span>📰 Muro de Noticias y Publicaciones de la Comunidad</span>
      </div>
      <div class="caja-body" id="feed-publicaciones" style="background: #f7f9fb; padding: 15px;">
        
        <?php if (!empty($publicaciones)): ?>
          <?php foreach ($publicaciones as $pub): ?>
            <article class="publicacion-card" id="pub-<?php echo (int)$pub['id_publicacion']; ?>">
              <div class="publicacion-header">
                <img src="<?php echo htmlspecialchars($pub['avatar'] ?: 'img/images.jpg'); ?>" alt="Avatar" class="publicacion-avatar">
                <div>
                  <div class="publicacion-autor"><?php echo htmlspecialchars($pub['autor_nombre']); ?></div>
                  <div class="publicacion-fecha">🕒 <?php echo htmlspecialchars($pub['fecha_formateada'] ?: $pub['fecha_publicacion']); ?></div>
                </div>
              </div>
              <div class="publicacion-cuerpo"><?php echo nl2br(htmlspecialchars($pub['contenido'])); ?></div>
              <div class="publicacion-acciones">
                <button type="button" class="btn-like" onclick="darLike(<?php echo (int)$pub['id_publicacion']; ?>)">
                  👍 Me gusta (<span id="likes-count-<?php echo (int)$pub['id_publicacion']; ?>"><?php echo (int)($pub['me_gusta'] ?? 0); ?></span>)
                </button>
                <a href="#" style="color: #3b5998; text-decoration: none;" onclick="alert('💬 Módulo de comentarios en desarrollo.'); return false;">💬 Comentar</a>
                <a href="#" style="color: #3b5998; text-decoration: none;" onclick="alert('🔗 Enlace copiado al portapapeles.'); return false;">🔗 Compartir</a>
              </div>
            </article>
          <?php endforeach; ?>
        <?php else: ?>
          <div style="text-align: center; padding: 30px; color: #666;">
            <p style="font-size: 15px;">📭 Aún no hay publicaciones en el muro.</p>
            <p style="font-size: 12px;">¡Sé el primero en publicar un mensaje arriba!</p>
          </div>
        <?php endif; ?>

      </div>
    </div>

  </section>

  <!-- COLUMNA DERECHA: AMIGUITOS, CATÁLOGO DE JUEGOS Y PERFILES -->
  <aside style="flex: 1; min-width: 280px;">

    <!-- PANEL DE AMIGUITOS DE LA COMUNIDAD -->
    <div class="caja" style="margin-bottom: 20px;">
      <div class="caja-header">
        <span>👥 Amiguitos Registrados (MySQL)</span>
      </div>
      <div class="caja-body" style="padding: 10px;">
        <ul style="list-style: none; padding: 0; margin: 0;">
          <?php if (!empty($amiguitos)): ?>
            <?php foreach ($amiguitos as $amigo): ?>
              <li style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; border-bottom: 1px dotted #eee; padding-bottom: 8px;">
                <img src="<?php echo htmlspecialchars($amigo['avatar'] ?: 'img/images.jpg'); ?>" alt="Avatar" width="38" height="38" style="border-radius: 4px; border: 1px solid #ccc; object-fit: cover;">
                <div style="flex: 1;">
                  <a href="<?php echo strtolower($amigo['nombre_usuario']) === 'ulises' ? 'ulises.html' : (strtolower($amigo['nombre_usuario']) === 'amir' ? 'amir.html' : '#'); ?>" style="font-weight: bold; color: #3b5998; text-decoration: none; font-size: 13px;">
                    <?php echo htmlspecialchars($amigo['nombre_usuario']); ?>
                  </a>
                  <div style="font-size: 11px; color: #777;">
                    <?php echo htmlspecialchars($amigo['ubicacion'] ?: 'Comunidad CP-ROS'); ?>
                  </div>
                </div>
                <span class="status-online" style="width: 8px; height: 8px; border-radius: 50%; background: #27ae60; display: inline-block;" title="En línea"></span>
              </li>
            <?php endforeach; ?>
          <?php else: ?>
            <li style="font-size: 12px; color: #777; text-align: center; padding: 10px;">No se encontraron usuarios en la BD.</li>
          <?php endif; ?>
        </ul>
      </div>
    </div>

    <!-- PANEL DE MINIJUEGOS RETRO -->
    <div class="caja">
      <div class="caja-header">
        <span>🎮 Minijuegos y Fichas Técnicas</span>
      </div>
      <div class="caja-body" style="padding: 10px; font-size: 12px;">
        <p style="margin: 0 0 10px; color: #555;">Explora las zonas de juegos retro:</p>
        <ul style="padding-left: 18px; margin: 0; line-height: 1.8;">
          <li><a href="skate2.html" style="color: #3b5998; font-weight: bold;">🛹 Skate 2</a> (Lyon 25 & Leo Messi)</li>
          <li><a href="minecraft3.html" style="color: #3b5998; font-weight: bold;">⛏️ Minecraft 3</a> (Gremio Constructor)</li>
          <li><a href="gun2.0.html" style="color: #3b5998; font-weight: bold;">🔫 Gun 2.0</a> (Escuadrón Táctico)</li>
          <li><a href="blue-spiral.html" style="color: #3b5998; font-weight: bold;">🌀 Blue Spiral</a> (Espiral Astral)</li>
          <li><a href="eyes-doom.html" style="color: #3b5998; font-weight: bold;">👁️ Eyes Doom</a> (Bestiario Abisal)</li>
          <li><a href="island-dead.html" style="color: #3b5998; font-weight: bold;">🧟 Island Dead</a> (Supervivencia Refugio)</li>
        </ul>
      </div>
    </div>

  </aside>

</main>

<!-- ==========================================================================
     VENTANA MODAL REUTILIZABLE PARA PANELES EMERGENTES
     ========================================================================== -->
<div id="modal-container" class="modal-overlay hidden" role="dialog" aria-modal="true">
  <div class="modal-content">
    <div class="caja-header">
      <span id="modal-title">Título</span>
      <button class="close-modal" aria-label="Cerrar modal" style="float: right;">✕</button>
    </div>
    <div class="caja-body" id="modal-body"></div>
  </div>
</div>

<script src="js/app.js"></script>

</body>
</html>
