<?php
/**
 * ARCHIVO DE CIERRE DE SESIÓN: logout.php
 * Red Social "CP-ROS" — Sopapa & Viridio
 *
 * Destruye la sesión activa del usuario y redirige al inicio de sesión (login.html).
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Limpiar todas las variables de sesión
$_SESSION = [];

// Destruir la cookie de sesión si existe
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// Destruir la sesión en el servidor
session_destroy();

// Redirigir a login.html
header('Location: login.html?mensaje=sesion_cerrada');
exit;
