<?php
/**
 * ENDPOINT API: Login (Inicio de Sesión)
 * Ruta: php/api/login.php
 * Método: POST
 *
 * Valida credenciales contra la base de datos MySQL con password_verify(),
 * inicia la sesión PHP e inicializa el estado del usuario como "online".
 */

session_start();

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['exito' => false, 'mensaje' => 'Método no permitido. Use POST.']);
    exit;
}

require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../modelos/InicioSesion.php';
require_once __DIR__ . '/../modelos/Usuario.php';
require_once __DIR__ . '/../modelos/ActividadUsuario.php';

// Leer datos (JSON o form-data)
$datos = json_decode(file_get_contents('php://input'), true);
if (!$datos || !is_array($datos)) {
    $datos = $_POST;
}

$usuarioLogin = isset($datos['usuario_login']) ? trim($datos['usuario_login']) : '';
$contrasena   = isset($datos['contrasena'])    ? $datos['contrasena']           : '';

if (empty($usuarioLogin) || empty($contrasena)) {
    http_response_code(400);
    echo json_encode(['exito' => false, 'mensaje' => 'Debe ingresar usuario y contraseña.']);
    exit;
}

// Verificar credenciales con password_verify() (y compatibilidad retroactiva segura)
$credenciales = InicioSesion::verificarCredenciales($usuarioLogin, $contrasena);

if (!$credenciales) {
    http_response_code(401);
    echo json_encode(['exito' => false, 'mensaje' => 'Usuario o contraseña incorrectos.']);
    exit;
}

$idUsuario = (int)$credenciales['id_usuario'];
$usuario   = Usuario::obtenerPorId($idUsuario);
$actividad = ActividadUsuario::obtenerPorIdUsuario($idUsuario);

// Marcar como online y registrar fecha de último login
$fechaActual = date('d/m/Y H:i');
ActividadUsuario::actualizarEstado($idUsuario, 'online');
ActividadUsuario::actualizarUltimoLogin($idUsuario, $fechaActual);

// Iniciar y almacenar datos en la sesión PHP
$_SESSION['id_usuario']     = $idUsuario;
$_SESSION['usuario_login']  = $credenciales['usuario_login'];
$_SESSION['nombre_usuario'] = $usuario ? $usuario['nombre_usuario'] : $credenciales['usuario_login'];
$_SESSION['avatar']         = $usuario ? $usuario['avatar'] : 'img/images.jpg';
$_SESSION['logueado']       = true;

$infoUsuario = [
    'id_usuario'     => $idUsuario,
    'usuario_login'  => $credenciales['usuario_login'],
    'nombre_usuario' => $usuario ? $usuario['nombre_usuario'] : $credenciales['usuario_login'],
    'avatar'         => $usuario ? $usuario['avatar'] : 'img/images.jpg',
    'fondo'          => $usuario ? $usuario['fondo'] : '',
    'estado'         => 'online',
    'edad_texto'     => $actividad ? $actividad['edad_texto'] : 'Sin especificar',
    'ubicacion'      => $actividad ? $actividad['ubicacion'] : 'Sin especificar',
    'ultimo_login'   => $fechaActual
];

http_response_code(200);
echo json_encode([
    'exito'   => true,
    'mensaje' => 'Inicio de sesión exitoso.',
    'usuario' => $infoUsuario,
    'datos'   => $infoUsuario
]);
