<?php
/**
 * ENDPOINT API: Logout (Cerrar Sesión)
 * Ruta: php/api/logout.php
 * Método: POST
 */

session_start();

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../modelos/ActividadUsuario.php';

// Actualizar estado a offline en la BD si había usuario en sesión
if (isset($_SESSION['id_usuario'])) {
    ActividadUsuario::actualizarEstado($_SESSION['id_usuario'], 'offline');
}

// Limpiar sesión en servidor
$_SESSION = [];

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();

// Si es llamado por navegador directo vía GET, redirigir a login.html
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Location: ../../login.html');
    exit;
}

http_response_code(200);
echo json_encode([
    'exito'   => true,
    'mensaje' => 'Sesión cerrada correctamente.'
]);
