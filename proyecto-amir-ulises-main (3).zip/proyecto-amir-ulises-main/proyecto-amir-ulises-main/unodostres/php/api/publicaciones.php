<?php
/**
 * ENDPOINT API: Publicaciones (Feed de Red Social)
 * Ruta: php/api/publicaciones.php
 * Métodos: GET, POST, DELETE
 *
 * Permite consultar y crear publicaciones en el feed dinámico de CP-ROS.
 */

session_start();

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../modelos/Publicacion.php';
require_once __DIR__ . '/../modelos/Usuario.php';

$metodo = $_SERVER['REQUEST_METHOD'];

// ============================================================================
// GET: Obtener publicaciones del feed
// ============================================================================
if ($metodo === 'GET') {
    $limite = isset($_GET['limite']) ? intval($_GET['limite']) : 20;
    if ($limite <= 0 || $limite > 100) $limite = 20;

    $publicaciones = Publicacion::obtenerFeed($limite);

    http_response_code(200);
    echo json_encode([
        'exito'         => true,
        'publicaciones' => $publicaciones,
        'datos'         => $publicaciones,
        'total'         => count($publicaciones)
    ]);
    exit;
}

// ============================================================================
// POST: Crear una nueva publicación
// ============================================================================
if ($metodo === 'POST') {
    $datos = json_decode(file_get_contents('php://input'), true);
    if (!$datos || !is_array($datos)) {
        $datos = $_POST;
    }

    $contenido = isset($datos['contenido']) ? trim($datos['contenido']) : '';
    $idUsuario = isset($datos['id_usuario']) ? intval($datos['id_usuario']) : (isset($_SESSION['id_usuario']) ? intval($_SESSION['id_usuario']) : 0);

    if (empty($contenido)) {
        http_response_code(400);
        echo json_encode(['exito' => false, 'mensaje' => 'El contenido de la publicación no puede estar vacío.']);
        exit;
    }

    if (!$idUsuario) {
        http_response_code(401);
        echo json_encode(['exito' => false, 'mensaje' => 'Debe iniciar sesión para realizar una publicación.']);
        exit;
    }

    // Verificar que el usuario exista
    $usuario = Usuario::obtenerPorId($idUsuario);
    if (!$usuario) {
        http_response_code(404);
        echo json_encode(['exito' => false, 'mensaje' => 'El usuario autor no existe.']);
        exit;
    }

    $idNuevaPub = Publicacion::crear($idUsuario, $contenido);

    if ($idNuevaPub) {
        http_response_code(201);
        echo json_encode([
            'exito'   => true,
            'mensaje' => '¡Publicación compartida con éxito en el feed!',
            'datos'   => [
                'id_publicacion'    => (int)$idNuevaPub,
                'id_usuario'        => $idUsuario,
                'nombre_usuario'    => $usuario['nombre_usuario'],
                'avatar'            => $usuario['avatar'],
                'contenido'         => htmlspecialchars($contenido, ENT_QUOTES, 'UTF-8'),
                'fecha_publicacion' => date('Y-m-d H:i:s')
            ]
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['exito' => false, 'mensaje' => 'No se pudo guardar la publicación en la base de datos.']);
    }
    exit;
}

// ============================================================================
// DELETE: Eliminar una publicación
// ============================================================================
if ($metodo === 'DELETE') {
    $datos = json_decode(file_get_contents('php://input'), true);
    $idPublicacion = isset($datos['id_publicacion']) ? intval($datos['id_publicacion']) : (isset($_GET['id']) ? intval($_GET['id']) : 0);
    $idUsuario     = isset($_SESSION['id_usuario']) ? intval($_SESSION['id_usuario']) : 0;

    if (!$idPublicacion || !$idUsuario) {
        http_response_code(400);
        echo json_encode(['exito' => false, 'mensaje' => 'Datos insuficientes para eliminar la publicación.']);
        exit;
    }

    $resultado = Publicacion::eliminar($idPublicacion, $idUsuario);

    if ($resultado) {
        http_response_code(200);
        echo json_encode(['exito' => true, 'mensaje' => 'Publicación eliminada correctamente.']);
    } else {
        http_response_code(500);
        echo json_encode(['exito' => false, 'mensaje' => 'No se pudo eliminar la publicación.']);
    }
    exit;
}

http_response_code(405);
echo json_encode(['exito' => false, 'mensaje' => 'Método no permitido.']);
