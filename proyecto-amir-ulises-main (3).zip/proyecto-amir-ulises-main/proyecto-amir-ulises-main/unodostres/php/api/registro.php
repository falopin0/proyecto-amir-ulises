<?php
/**
 * ENDPOINT API: Registro de Usuario Nuevo
 * Ruta: php/api/registro.php
 * Método: POST
 *
 * Recibe los datos de un nuevo usuario (nombre_usuario, usuario_login, contrasena, correo)
 * vía POST (soporta JSON o form-data).
 * Inserta en forma atómica (transacción) en:
 * - usuario (perfil público)
 * - inicio_sesion (credenciales con password_hash())
 * - actividad_usuario (datos biográficos)
 * - registro (metadatos de cuenta)
 */

session_start();

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Responder a preflight CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Solo aceptar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['exito' => false, 'mensaje' => 'Método no permitido. Use POST.']);
    exit;
}

// Cargar modelos y conexión
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../modelos/Usuario.php';
require_once __DIR__ . '/../modelos/InicioSesion.php';
require_once __DIR__ . '/../modelos/ActividadUsuario.php';
require_once __DIR__ . '/../modelos/Registro.php';

// Leer datos (JSON o POST)
$entrada = json_decode(file_get_contents('php://input'), true);
if (!$entrada || !is_array($entrada)) {
    $entrada = $_POST;
}

// Validar que se recibieron todos los campos requeridos
if (
    empty($entrada['nombre_usuario']) ||
    empty($entrada['usuario_login']) ||
    empty($entrada['contrasena']) ||
    empty($entrada['correo'])
) {
    http_response_code(400);
    echo json_encode([
        'exito'   => false,
        'mensaje' => 'Todos los campos son obligatorios: Nombre de Usuario, Usuario de Login, Contraseña y Correo Electrónico.'
    ]);
    exit;
}

$nombreUsuario = trim($entrada['nombre_usuario']);
$usuarioLogin  = trim($entrada['usuario_login']);
$contrasena    = $entrada['contrasena'];
$correo        = trim($entrada['correo']);

// Validaciones de formato
if (mb_strlen($nombreUsuario, 'UTF-8') < 3 || mb_strlen($nombreUsuario, 'UTF-8') > 50) {
    http_response_code(400);
    echo json_encode(['exito' => false, 'mensaje' => 'El nombre de usuario debe tener entre 3 y 50 caracteres.']);
    exit;
}

if (mb_strlen($usuarioLogin, 'UTF-8') < 3 || mb_strlen($usuarioLogin, 'UTF-8') > 50) {
    http_response_code(400);
    echo json_encode(['exito' => false, 'mensaje' => 'El usuario de login debe tener entre 3 y 50 caracteres.']);
    exit;
}

if (strlen($contrasena) < 4) {
    http_response_code(400);
    echo json_encode(['exito' => false, 'mensaje' => 'La contraseña debe tener al menos 4 caracteres.']);
    exit;
}

if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['exito' => false, 'mensaje' => 'El correo electrónico no tiene un formato válido.']);
    exit;
}

$db = obtenerConexion();
if (!$db) {
    http_response_code(500);
    echo json_encode([
        'exito'   => false,
        'mensaje' => 'Error de conexión con la base de datos. Verifique que el servicio MySQL esté activo.'
    ]);
    exit;
}

try {
    // 1. Verificar si el usuario_login ya existe en inicio_sesion
    $existeLogin = InicioSesion::obtenerPorUsuarioLogin($usuarioLogin);
    if ($existeLogin) {
        http_response_code(409);
        echo json_encode(['exito' => false, 'mensaje' => 'El nombre de usuario de login ya está registrado. Elija otro.']);
        exit;
    }

    // 2. Verificar si el correo ya está registrado
    $existeCorreo = Registro::obtenerPorCorreo($correo);
    if ($existeCorreo) {
        http_response_code(409);
        echo json_encode(['exito' => false, 'mensaje' => 'El correo electrónico ya está registrado en otra cuenta.']);
        exit;
    }

    // 3. Verificar si el nombre_usuario público ya existe
    $existeNombre = Usuario::obtenerPorNombre($nombreUsuario);
    if ($existeNombre) {
        http_response_code(409);
        echo json_encode(['exito' => false, 'mensaje' => 'El nombre de usuario público ya está en uso.']);
        exit;
    }

    // Iniciar transacción atómica
    $db->beginTransaction();

    // 1. Insertar perfil en `usuario`
    $idUsuarioNuevo = Usuario::crear($nombreUsuario, 'img/images.jpg', '');
    if (!$idUsuarioNuevo) {
        throw new Exception("No se pudo registrar el perfil en la tabla usuario.");
    }

    // 2. Insertar credenciales en `inicio_sesion` con password_hash()
    $hashSeguro = password_hash($contrasena, PASSWORD_DEFAULT);
    $hex = bin2hex($contrasena);

    // Intentar insertar soportando esquemas con contrasena_hash o contrasena_hex
    try {
        $stmtLogin = $db->prepare(
            "INSERT INTO inicio_sesion (id_usuario, usuario_login, contrasena_hash, contrasena_hex)
             VALUES (:id, :login, :hash, :hex)"
        );
        $stmtLogin->execute([
            ':id'    => $idUsuarioNuevo,
            ':login' => $usuarioLogin,
            ':hash'  => $hashSeguro,
            ':hex'   => $hex
        ]);
    } catch (PDOException $eLogin) {
        $stmtLogin = $db->prepare(
            "INSERT INTO inicio_sesion (id_usuario, usuario_login, contrasena_hex)
             VALUES (:id, :login, :pass)"
        );
        $stmtLogin->execute([
            ':id'    => $idUsuarioNuevo,
            ':login' => $usuarioLogin,
            ':pass'  => $hashSeguro
        ]);
    }

    // 3. Insertar datos en `actividad_usuario`
    $stmtActividad = $db->prepare(
        "INSERT INTO actividad_usuario (id_usuario, estado, edad_texto, ubicacion, ultimo_login)
         VALUES (:id, 'offline', 'Sin especificar', 'Sin especificar', NOW())"
    );
    $stmtActividad->execute([':id' => $idUsuarioNuevo]);

    // 4. Insertar datos en `registro`
    $stmtRegistro = $db->prepare(
        "INSERT INTO registro (id_usuario, correo_electronico, fecha_registro, estado_cuenta)
         VALUES (:id, :correo, NOW(), 'activa')"
    );
    $stmtRegistro->execute([
        ':id'     => $idUsuarioNuevo,
        ':correo' => $correo
    ]);

    // Confirmar transacción
    $db->commit();

    http_response_code(201);
    echo json_encode([
        'exito'   => true,
        'mensaje' => '¡Cuenta creada exitosamente! Ya puedes iniciar sesión.',
        'datos'   => [
            'id_usuario'     => (int)$idUsuarioNuevo,
            'nombre_usuario' => $nombreUsuario,
            'usuario_login'  => $usuarioLogin,
            'correo'         => $correo
        ]
    ]);

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    error_log("[CP-ROS] Error en registro de usuario: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'exito'   => false,
        'mensaje' => 'Error interno del servidor al registrar la cuenta. Intente más tarde.'
    ]);
}
