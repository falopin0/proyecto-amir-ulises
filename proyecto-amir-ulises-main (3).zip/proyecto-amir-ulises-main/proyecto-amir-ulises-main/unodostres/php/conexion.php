<?php
/**
 * Conexión centralizada - Alias en carpeta php/
 */
require_once __DIR__ . '/../conexion.php';
