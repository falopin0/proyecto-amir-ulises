<?php
/**
 * ARCHIVO DE CONFIGURACIÓN Y CONEXIÓN A LA BASE DE DATOS
 * Red Social "CP-ROS" — Sopapa & Viridio
 *
 * Reutiliza y delega la conexión centralizada en conexion.php.
 */

require_once __DIR__ . '/../../conexion.php';
