<?php
/**
 * MODELO: ActividadUsuario
 * Tabla: actividad_usuario (Base de datos: u283509122_cyp)
 * Campos: id_actividad, id_usuario, estado, edad_texto, ubicacion, ultimo_login
 *
 * Gestiona el estado de conexión (online/offline) y datos biográficos.
 */

require_once __DIR__ . '/../conexion.php';

class ActividadUsuario {

    /**
     * Obtener la actividad/datos biográficos de un usuario por su ID.
     * @param int $idUsuario ID del usuario.
     * @return array|false Datos de actividad o false si no existe.
     */
    public static function obtenerPorIdUsuario($idUsuario) {
        $db = obtenerConexion();
        if (!$db) return false;

        $stmt = $db->prepare("SELECT id_actividad, id_usuario, estado, edad_texto, ubicacion, ultimo_login FROM actividad_usuario WHERE id_usuario = :id LIMIT 1");
        $stmt->execute([':id' => $idUsuario]);
        return $stmt->fetch();
    }

    /**
     * Actualizar el estado de conexión de un usuario ('online', 'offline').
     * @param int $idUsuario ID del usuario.
     * @param string $estado Nuevo estado.
     * @return bool True si se actualizó correctamente.
     */
    public static function actualizarEstado($idUsuario, $estado) {
        $db = obtenerConexion();
        if (!$db) return false;

        try {
            $stmt = $db->prepare("UPDATE actividad_usuario SET estado = :estado WHERE id_usuario = :id");
            return $stmt->execute([':estado' => $estado, ':id' => $idUsuario]);
        } catch (PDOException $e) {
            error_log("Error al actualizar estado: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Actualizar la fecha/texto de último login.
     * @param int $idUsuario ID del usuario.
     * @param string $ultimoLogin Texto o fecha del último login.
     * @return bool True si se actualizó correctamente.
     */
    public static function actualizarUltimoLogin($idUsuario, $ultimoLogin) {
        $db = obtenerConexion();
        if (!$db) return false;

        try {
            $stmt = $db->prepare("UPDATE actividad_usuario SET ultimo_login = :ultimo WHERE id_usuario = :id");
            return $stmt->execute([':ultimo' => $ultimoLogin, ':id' => $idUsuario]);
        } catch (PDOException $e) {
            error_log("Error al actualizar ultimo_login: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Crear el registro inicial de actividad para un nuevo usuario.
     */
    public static function crear($idUsuario, $estado = 'offline', $edad = 'Sin especificar', $ubicacion = 'Sin especificar') {
        $db = obtenerConexion();
        if (!$db) return false;

        $stmt = $db->prepare(
            "INSERT INTO actividad_usuario (id_usuario, estado, edad_texto, ubicacion, ultimo_login)
             VALUES (:id, :estado, :edad, :ubicacion, NOW())"
        );
        return $stmt->execute([
            ':id'        => $idUsuario,
            ':estado'    => $estado,
            ':edad'      => $edad,
            ':ubicacion' => $ubicacion
        ]);
    }

    /**
     * Obtener todos los usuarios con su estado de actividad.
     * @return array Lista de actividades de todos los usuarios.
     */
    public static function listarTodos() {
        $db = obtenerConexion();
        if (!$db) return [];

        $stmt = $db->query("SELECT id_actividad, id_usuario, estado, edad_texto, ubicacion, ultimo_login FROM actividad_usuario ORDER BY id_usuario ASC");
        return $stmt->fetchAll() ?: [];
    }
}
