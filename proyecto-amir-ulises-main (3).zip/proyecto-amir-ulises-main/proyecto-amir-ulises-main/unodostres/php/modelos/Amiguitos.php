<?php
/**
 * MODELO: Amiguitos
 * Tabla: amiguitos (Base de datos: u283509122_cyp)
 * Campos: id_amiguito, id_usuario_propietario, id_usuario_amigo, fecha_agregado, estado_amistad
 *
 * Gestiona las relaciones de amistad entre usuarios de CP-ROS.
 */

require_once __DIR__ . '/../conexion.php';

class Amiguitos {

    /**
     * Obtener la lista de amigos de un usuario por su ID.
     * Incluye datos del usuario amigo mediante JOIN con la tabla usuario y actividad_usuario.
     * @param int $idUsuarioPropietario ID del usuario.
     * @return array Lista de amigos.
     */
    public static function obtenerAmigosPorUsuario($idUsuarioPropietario) {
        $db = obtenerConexion();
        if (!$db) return [];

        try {
            $stmt = $db->prepare(
                "SELECT a.id_amiguito, a.id_usuario_amigo, a.fecha_agregado, a.estado_amistad,
                        u.nombre_usuario, u.avatar,
                        COALESCE(act.estado, 'offline') AS estado
                 FROM amiguitos a
                 INNER JOIN usuario u ON a.id_usuario_amigo = u.id_usuario
                 LEFT JOIN actividad_usuario act ON u.id_usuario = act.id_usuario
                 WHERE a.id_usuario_propietario = :id
                 ORDER BY a.fecha_agregado DESC"
            );
            $stmt->execute([':id' => $idUsuarioPropietario]);
            return $stmt->fetchAll() ?: [];
        } catch (PDOException $e) {
            error_log("Error al obtener amigos: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Listar todos los amigos de la comunidad para el feed general (cuando no hay filtro específico).
     * @param int $limite
     * @return array
     */
    public static function listarAmiguitosComunidad($limite = 12) {
        $db = obtenerConexion();
        if (!$db) return [];

        try {
            $stmt = $db->prepare(
                "SELECT u.id_usuario, u.nombre_usuario, u.avatar,
                        COALESCE(a.estado, 'offline') AS estado,
                        COALESCE(a.edad_texto, 'Sin especificar') AS edad_texto,
                        COALESCE(a.ubicacion, 'Sin especificar') AS ubicacion
                 FROM usuario u
                 LEFT JOIN actividad_usuario a ON u.id_usuario = a.id_usuario
                 ORDER BY u.id_usuario ASC
                 LIMIT :limite"
            );
            $stmt->bindValue(':limite', (int)$limite, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll() ?: [];
        } catch (PDOException $e) {
            error_log("Error al listar amiguitos de comunidad: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Agregar un nuevo amigo a la lista de un usuario.
     */
    public static function agregarAmigo($idPropietario, $idAmigo) {
        $db = obtenerConexion();
        if (!$db) return false;

        try {
            $stmt = $db->prepare(
                "INSERT INTO amiguitos (id_usuario_propietario, id_usuario_amigo, fecha_agregado, estado_amistad)
                 VALUES (:propietario, :amigo, NOW(), 'aceptado')"
            );
            return $stmt->execute([':propietario' => $idPropietario, ':amigo' => $idAmigo]);
        } catch (PDOException $e) {
            error_log("Error al agregar amigo: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Actualizar el estado de una amistad ('aceptado', 'rechazado', 'pendiente').
     */
    public static function actualizarEstado($idAmiguito, $estado) {
        $db = obtenerConexion();
        if (!$db) return false;

        try {
            $stmt = $db->prepare("UPDATE amiguitos SET estado_amistad = :estado WHERE id_amiguito = :id");
            return $stmt->execute([':estado' => $estado, ':id' => $idAmiguito]);
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Eliminar una relación de amistad.
     */
    public static function eliminarAmigo($idAmiguito) {
        $db = obtenerConexion();
        if (!$db) return false;

        try {
            $stmt = $db->prepare("DELETE FROM amiguitos WHERE id_amiguito = :id");
            return $stmt->execute([':id' => $idAmiguito]);
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Verificar si dos usuarios ya son amigos.
     */
    public static function verificarAmistad($idPropietario, $idAmigo) {
        $db = obtenerConexion();
        if (!$db) return false;

        try {
            $stmt = $db->prepare(
                "SELECT id_amiguito, estado_amistad FROM amiguitos
                 WHERE id_usuario_propietario = :propietario AND id_usuario_amigo = :amigo LIMIT 1"
            );
            $stmt->execute([':propietario' => $idPropietario, ':amigo' => $idAmigo]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            return false;
        }
    }
}
