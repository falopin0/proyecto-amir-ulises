<?php
/**
 * MODELO: InicioSesion
 * Tabla: inicio_sesion (Base de datos: u283509122_cyp)
 * Campos: id_inicio_sesion, id_usuario, usuario_login, contrasena_hash (o contrasena_hex)
 *
 * Gestiona la autenticación y las credenciales de acceso de los usuarios.
 * Implementa almacenamiento seguro mediante password_hash() y verificación
 * mediante password_verify(), previniendo contraseñas en texto plano.
 */

require_once __DIR__ . '/../conexion.php';

class InicioSesion {

    /**
     * Buscar credenciales por nombre de usuario de login.
     * @param string $usuarioLogin Nombre de usuario para el login.
     * @return array|false Datos de credenciales o false si no existe.
     */
    public static function obtenerPorUsuarioLogin($usuarioLogin) {
        $db = obtenerConexion();
        if (!$db) return false;

        $stmt = $db->prepare("SELECT * FROM inicio_sesion WHERE usuario_login = :usuario LIMIT 1");
        $stmt->execute([':usuario' => $usuarioLogin]);
        return $stmt->fetch();
    }

    /**
     * Verificar las credenciales de un usuario mediante password_verify().
     * Incluye compatibilidad hacia atrás con re-hashing seguro si detecta credenciales antiguas.
     *
     * @param string $usuarioLogin Nombre de usuario ingresado en el formulario.
     * @param string $contrasena Contraseña ingresada en texto plano.
     * @return array|false Datos del usuario si las credenciales son válidas, false en caso contrario.
     */
    public static function verificarCredenciales($usuarioLogin, $contrasena) {
        $credenciales = self::obtenerPorUsuarioLogin($usuarioLogin);

        if (!$credenciales) {
            return false;
        }

        // Obtener el valor de la contraseña almacenada (sea contrasena_hash o contrasena_hex)
        $hashAlmacenado = isset($credenciales['contrasena_hash']) 
            ? $credenciales['contrasena_hash'] 
            : (isset($credenciales['contrasena_hex']) ? $credenciales['contrasena_hex'] : '');

        // 1. Verificación estándar con password_verify()
        if (password_verify($contrasena, $hashAlmacenado)) {
            // Si el algoritmo requiere rehash, se actualiza automáticamente
            if (password_needs_rehash($hashAlmacenado, PASSWORD_DEFAULT)) {
                self::actualizarContrasena($credenciales['id_usuario'], $contrasena);
            }
            return $credenciales;
        }

        // 2. Compatibilidad retroactiva: si la contraseña en BD estaba en formato hexadecimal (bin2hex)
        $contrasenaHex = bin2hex($contrasena);
        if ($hashAlmacenado === $contrasenaHex) {
            // Migrar automáticamente la contraseña a password_hash() seguro
            self::actualizarContrasena($credenciales['id_usuario'], $contrasena);
            return $credenciales;
        }

        // 3. Compatibilidad con texto plano de prueba previa
        if ($hashAlmacenado === $contrasena) {
            self::actualizarContrasena($credenciales['id_usuario'], $contrasena);
            return $credenciales;
        }

        return false;
    }

    /**
     * Crear un nuevo registro de credenciales con password_hash().
     *
     * @param int $idUsuario ID del usuario registrado.
     * @param string $usuarioLogin Nombre de usuario de login.
     * @param string $contrasena Contraseña en texto plano a ser hasheada.
     * @return bool True si se insertó correctamente.
     */
    public static function crearCredenciales($idUsuario, $usuarioLogin, $contrasena) {
        $db = obtenerConexion();
        if (!$db) return false;

        $hash = password_hash($contrasena, PASSWORD_DEFAULT);
        $hex = bin2hex($contrasena);

        // Detectar si la tabla tiene columna contrasena_hash o contrasena_hex
        try {
            $stmt = $db->prepare(
                "INSERT INTO inicio_sesion (id_usuario, usuario_login, contrasena_hash, contrasena_hex) 
                 VALUES (:id, :login, :hash, :hex)"
            );
            return $stmt->execute([
                ':id'    => $idUsuario,
                ':login' => $usuarioLogin,
                ':hash'  => $hash,
                ':hex'   => $hex
            ]);
        } catch (PDOException $e) {
            // Fallback si la columna contrasena_hash aún no existe en el esquema previo de la BD
            try {
                $stmt = $db->prepare(
                    "INSERT INTO inicio_sesion (id_usuario, usuario_login, contrasena_hex) 
                     VALUES (:id, :login, :pass)"
                );
                return $stmt->execute([
                    ':id'    => $idUsuario,
                    ':login' => $usuarioLogin,
                    ':pass'  => $hash // Guardamos el hash en el campo existente
                ]);
            } catch (PDOException $e2) {
                error_log("Error al insertar en inicio_sesion: " . $e2->getMessage());
                return false;
            }
        }
    }

    /**
     * Actualizar la contraseña de un usuario a un hash seguro BCRYPT/ARGON2.
     * @param int $idUsuario ID del usuario.
     * @param string $nuevaContrasena Contraseña en texto plano.
     * @return bool True si se actualizó.
     */
    public static function actualizarContrasena($idUsuario, $nuevaContrasena) {
        $db = obtenerConexion();
        if (!$db) return false;

        $hash = password_hash($nuevaContrasena, PASSWORD_DEFAULT);
        $hex = bin2hex($nuevaContrasena);

        try {
            $stmt = $db->prepare("UPDATE inicio_sesion SET contrasena_hash = :hash, contrasena_hex = :hex WHERE id_usuario = :id");
            return $stmt->execute([':hash' => $hash, ':hex' => $hex, ':id' => $idUsuario]);
        } catch (PDOException $e) {
            $stmt = $db->prepare("UPDATE inicio_sesion SET contrasena_hex = :hash WHERE id_usuario = :id");
            return $stmt->execute([':hash' => $hash, ':id' => $idUsuario]);
        }
    }

    /**
     * Obtener credenciales por ID de usuario.
     * @param int $idUsuario ID del usuario.
     * @return array|false Datos de credenciales o false.
     */
    public static function obtenerPorIdUsuario($idUsuario) {
        $db = obtenerConexion();
        if (!$db) return false;

        $stmt = $db->prepare("SELECT * FROM inicio_sesion WHERE id_usuario = :id LIMIT 1");
        $stmt->execute([':id' => $idUsuario]);
        return $stmt->fetch();
    }
}
