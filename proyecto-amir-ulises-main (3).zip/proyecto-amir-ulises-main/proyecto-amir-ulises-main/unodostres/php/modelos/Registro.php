<?php
/**
 * MODELO: Registro
 * Tabla: registro (Base de datos: u283509122_cyp)
 * Campos: id_registro, id_usuario, correo_electronico, fecha_registro, estado_cuenta
 *
 * Gestiona el registro de cuentas y estado de usuarios en CP-ROS.
 */

require_once __DIR__ . '/../conexion.php';

class Registro {

    /**
     * Obtener los datos de registro de un usuario por su ID.
     */
    public static function obtenerPorIdUsuario($idUsuario) {
        $db = obtenerConexion();
        if (!$db) return false;

        $stmt = $db->prepare("SELECT id_registro, id_usuario, correo_electronico, fecha_registro, estado_cuenta FROM registro WHERE id_usuario = :id LIMIT 1");
        $stmt->execute([':id' => $idUsuario]);
        return $stmt->fetch();
    }

    /**
     * Buscar un registro por correo electrónico.
     */
    public static function obtenerPorCorreo($correo) {
        $db = obtenerConexion();
        if (!$db) return false;

        $stmt = $db->prepare("SELECT id_registro, id_usuario, correo_electronico, fecha_registro, estado_cuenta FROM registro WHERE correo_electronico = :correo LIMIT 1");
        $stmt->execute([':correo' => $correo]);
        return $stmt->fetch();
    }

    /**
     * Crear un nuevo registro de cuenta.
     */
    public static function crearRegistro($idUsuario, $correo) {
        $db = obtenerConexion();
        if (!$db) return false;

        $stmt = $db->prepare(
            "INSERT INTO registro (id_usuario, correo_electronico, fecha_registro, estado_cuenta)
             VALUES (:id, :correo, NOW(), 'activa')"
        );
        return $stmt->execute([':id' => $idUsuario, ':correo' => $correo]);
    }

    /**
     * Actualizar el estado de una cuenta.
     */
    public static function actualizarEstadoCuenta($idUsuario, $estado) {
        $db = obtenerConexion();
        if (!$db) return false;

        $stmt = $db->prepare("UPDATE registro SET estado_cuenta = :estado WHERE id_usuario = :id");
        return $stmt->execute([':estado' => $estado, ':id' => $idUsuario]);
    }

    /**
     * Listar todos los registros.
     */
    public static function listarTodos() {
        $db = obtenerConexion();
        if (!$db) return [];

        $stmt = $db->query("SELECT id_registro, id_usuario, correo_electronico, fecha_registro, estado_cuenta FROM registro ORDER BY fecha_registro DESC");
        return $stmt->fetchAll() ?: [];
    }
}
