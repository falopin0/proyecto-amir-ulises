<?php
/**
 * MODELO: Usuario
 * Tabla: usuario (Base de datos: u283509122_cyp)
 * Campos: id_usuario, nombre_usuario, avatar, fondo
 *
 * Encapsula operaciones CRUD para la tabla `usuario`.
 * Contiene datos de perfil público de cada usuario de CP-ROS.
 */

require_once __DIR__ . '/../conexion.php';

class Usuario {

    /**
     * Obtener un usuario por su ID.
     * @param int $idUsuario ID del usuario a buscar.
     * @return array|false Datos del usuario o false si no existe.
     */
    public static function obtenerPorId($idUsuario) {
        $db = obtenerConexion();
        if (!$db) return false;

        $stmt = $db->prepare("SELECT id_usuario, nombre_usuario, avatar, fondo FROM usuario WHERE id_usuario = :id LIMIT 1");
        $stmt->execute([':id' => $idUsuario]);
        return $stmt->fetch();
    }

    /**
     * Obtener un usuario por su nombre de usuario.
     * @param string $nombreUsuario Nombre de usuario a buscar.
     * @return array|false Datos del usuario o false si no existe.
     */
    public static function obtenerPorNombre($nombreUsuario) {
        $db = obtenerConexion();
        if (!$db) return false;

        $stmt = $db->prepare("SELECT id_usuario, nombre_usuario, avatar, fondo FROM usuario WHERE nombre_usuario = :nombre LIMIT 1");
        $stmt->execute([':nombre' => $nombreUsuario]);
        return $stmt->fetch();
    }

    /**
     * Listar todos los usuarios registrados con su información biográfica y estado.
     * @return array Lista de usuarios.
     */
    public static function listarTodosConActividad() {
        $db = obtenerConexion();
        if (!$db) return [];

        try {
            $stmt = $db->query(
                "SELECT u.id_usuario, u.nombre_usuario, u.avatar, u.fondo,
                        a.estado, a.edad_texto, a.ubicacion, a.ultimo_login
                 FROM usuario u
                 LEFT JOIN actividad_usuario a ON u.id_usuario = a.id_usuario
                 ORDER BY u.id_usuario ASC"
            );
            return $stmt->fetchAll() ?: [];
        } catch (PDOException $e) {
            return self::listarTodos();
        }
    }

    /**
     * Listar todos los usuarios registrados.
     * @return array Lista de usuarios.
     */
    public static function listarTodos() {
        $db = obtenerConexion();
        if (!$db) return [];

        $stmt = $db->query("SELECT id_usuario, nombre_usuario, avatar, fondo FROM usuario ORDER BY nombre_usuario ASC");
        return $stmt->fetchAll() ?: [];
    }

    /**
     * Crear un nuevo usuario en la tabla `usuario`.
     * @param string $nombreUsuario
     * @param string $avatar
     * @param string $fondo
     * @return int|false ID insertado o false
     */
    public static function crear($nombreUsuario, $avatar = 'img/images.jpg', $fondo = '') {
        $db = obtenerConexion();
        if (!$db) return false;

        $stmt = $db->prepare("INSERT INTO usuario (nombre_usuario, avatar, fondo) VALUES (:nombre, :avatar, :fondo)");
        $exito = $stmt->execute([
            ':nombre' => $nombreUsuario,
            ':avatar' => $avatar,
            ':fondo'  => $fondo
        ]);

        return $exito ? (int)$db->lastInsertId() : false;
    }

    /**
     * Actualizar el avatar de un usuario.
     * @param int $idUsuario ID del usuario.
     * @param string $avatar Ruta o URL del nuevo avatar.
     * @return bool True si se actualizó correctamente.
     */
    public static function actualizarAvatar($idUsuario, $avatar) {
        $db = obtenerConexion();
        if (!$db) return false;

        $stmt = $db->prepare("UPDATE usuario SET avatar = :avatar WHERE id_usuario = :id");
        return $stmt->execute([':avatar' => $avatar, ':id' => $idUsuario]);
    }

    /**
     * Actualizar el fondo de perfil de un usuario.
     * @param int $idUsuario ID del usuario.
     * @param string $fondo Ruta o URL del nuevo fondo.
     * @return bool True si se actualizó correctamente.
     */
    public static function actualizarFondo($idUsuario, $fondo) {
        $db = obtenerConexion();
        if (!$db) return false;

        $stmt = $db->prepare("UPDATE usuario SET fondo = :fondo WHERE id_usuario = :id");
        return $stmt->execute([':fondo' => $fondo, ':id' => $idUsuario]);
    }
}
