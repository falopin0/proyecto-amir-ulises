document.addEventListener('DOMContentLoaded', () => {
  // SECCIÓN INICIO: Manejo del Login
  // Esta parte se encarga de dar la bienvenida al usuario al ingresar su nombre.
  const loginForm = document.querySelector('fieldset form');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const usuario = document.getElementById('usuario').value;
      if (usuario) {
        alert(`¡Bienvenido, ${usuario}! Has iniciado sesión correctamente.`);
        // Guardar en localStorage para persistencia básica
        localStorage.setItem('usuarioLogueado', usuario);
        // Cambiar el texto de bienvenida en la barra superior
        const welcomeSpan = document.querySelector('.top-bar-right span');
        if (welcomeSpan) {
          welcomeSpan.textContent = `Bienvenido(a), ${usuario}`;
        }
      } else {
        alert('Por favor, ingresa un nombre de usuario.');
      }
    });
  }

  // Verificar si hay un usuario logueado al cargar
  const usuarioGuardado = localStorage.getItem('usuarioLogueado');
  if (usuarioGuardado) {
    const welcomeSpan = document.querySelector('.top-bar-right span');
    if (welcomeSpan) {
      welcomeSpan.textContent = `Bienvenido(a), ${usuarioGuardado}`;
    }
  }

  // Manejo del Logout
  const btnLogout = document.getElementById('btn-logout');
  if (btnLogout) {
    btnLogout.addEventListener('click', () => {
      localStorage.removeItem('usuarioLogueado');
      // No alert here, just let the link redirect to login.html
    });
  }

  // SECCIÓN NAVEGACIÓN: Manejo de Paneles Emergentes (Modales)
  // Sistema centralizado para abrir y cerrar ventanas emergentes con información dinámica.
  const modalContainer = document.getElementById('modal-container');
  const modalTitle = document.getElementById('modal-title');
  const modalBody = document.getElementById('modal-body');
  const closeModalBtn = document.querySelector('.close-modal');

  // Asegurar que el modal esté en el DOM si no existe (para páginas de juegos)
  if (!modalContainer && (
    document.querySelector('.btn-notificaciones') ||
    document.querySelector('.btn-solicitudes') ||
    document.querySelector('.btn-amiguitos') ||
    document.querySelector('.btn-mensajes')
  )) {
    const modalHTML = `
      <div id="modal-container" class="modal-overlay hidden">
        <div class="modal-content">
          <div class="caja-header">
            <span id="modal-title">Título</span>
            <button class="close-modal" style="float: right;">X</button>
          </div>
          <div class="caja-body" id="modal-body">
            <!-- Contenido dinámico -->
          </div>
        </div>
      </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHTML);

    // Re-seleccionar elementos tras la inserción
    const newModalContainer = document.getElementById('modal-container');
    const newModalTitle = document.getElementById('modal-title');
    const newModalBody = document.getElementById('modal-body');
    const newCloseModalBtn = document.querySelector('.close-modal');

    // Funciones locales para el nuevo modal
    const openModalNew = (title, content) => {
      newModalTitle.textContent = title;
      newModalBody.innerHTML = content;
      newModalContainer.classList.remove('hidden');
    };

    newCloseModalBtn.addEventListener('click', () => newModalContainer.classList.add('hidden'));

    setupEventListeners(openModalNew);
  } else if (modalContainer) {
    const openModal = (title, content) => {
      modalTitle.textContent = title;
      modalBody.innerHTML = content;
      modalContainer.classList.remove('hidden');
    };

    if (closeModalBtn) {
      closeModalBtn.addEventListener('click', () => modalContainer.classList.add('hidden'));
    }

    setupEventListeners(openModal);
  }

  function setupEventListeners(openModalFn) {
    // SECCIÓN NOTIFICACIONES
    const btnNotif = document.querySelectorAll('.btn-notificaciones');
    btnNotif.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        openModalFn('Notificaciones', `
          <p><i>Este panel sirve para estar al tanto de lo que pasa en tu red y no perderte nada importante.</i></p>
          <hr>
          <ul>
            <li>🔔 <b>ulisesl+kpo</b> te ha enviado un mensaje.</li>
            <li>🔔 Tienes una nueva solicitud de amistad.</li>
            <li>🔔 El juego <b>Minecraft 3</b> se ha actualizado.</li>
          </ul>
        `);
      });
    });

    // SECCIÓN SOLICITUDES
    const btnSolicitudes = document.querySelectorAll('.btn-solicitudes');
    btnSolicitudes.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        openModalFn('Solicitudes de Amistad', `
          <p><i>Aquí puedes gestionar quién puede contactarte y ver tu perfil privado.</i></p>
          <hr>
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
            <span>👤 <b>rompeviejas747</b> quiere ser tu amigo.</span>
            <div>
              <button onclick="alert('Aceptado')">Aceptar</button>
              <button onclick="alert('Rechazado')" style="background: #ff4d4d;">Rechazar</button>
            </div>
          </div>
        `);
      });
    });

    // SECCIÓN AMIGUITOS
    const btnAmiguitos = document.querySelectorAll('.btn-amiguitos');
    btnAmiguitos.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        openModalFn('Lista de Amiguitos', `
          <p><i>Tu red de contactos cercana para jugar y chatear rápidamente.</i></p>
          <hr>
          <div class="grid-amigos">
            <div class="amigo-item">
              <div class="amigo-pic" style="background-image: url('https://i.pravatar.cc/60?u=10')"></div>
              <div class="amigo-nombre">Nico</div>
            </div>
            <div class="amigo-item">
              <div class="amigo-pic" style="background-image: url('https://i.pravatar.cc/60?u=11')"></div>
              <div class="amigo-nombre">Shadow</div>
            </div>
            <div class="amigo-item">
              <div class="amigo-pic" style="background-image: url('https://i.pravatar.cc/60?u=12')"></div>
              <div class="amigo-nombre">Goku</div>
            </div>
          </div>
        `);
      });
    });

    // SECCIÓN MENSAJES
    const btnMensajes = document.querySelectorAll('.btn-mensajes');
    btnMensajes.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        openModalFn('Enviar Mensaje', `
          <p><i>Envía mensajes privados a otros usuarios para coordinar partidas o charlar.</i></p>
          <hr>
          <textarea placeholder="Escribe tu mensaje aquí..." style="width: 100%; height: 100px; margin-bottom: 10px;"></textarea>
          <button onclick="alert('Mensaje enviado'); const mc = document.getElementById('modal-container'); if(mc) mc.classList.add('hidden');">Enviar</button>
        `);
      });
    });
  }

  // SECCIÓN PERSONALIZACIÓN: Manejo de Fondo
  // Permite al usuario subir una imagen para cambiar el aspecto visual del sitio.
  const btnPersonalizar = document.getElementById('btn-personalizar');
  const bgUpload = document.getElementById('bg-upload');

  if (btnPersonalizar && bgUpload) {
    btnPersonalizar.addEventListener('click', () => {
      bgUpload.click();
    });

    bgUpload.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          document.body.style.backgroundImage = `url('${event.target.result}')`;
          document.body.classList.add('custom-bg');
        };
        reader.readAsDataURL(file);
      }
    });
  }
});
